# 2. Công thức tùy chỉnh và lưu trữ (khách tự tạo đồ uống)

Khách chọn món nền, chọn size, đường, đá, sữa, topping; giá tự tính; thêm vào giỏ món tự tạo và đặt hàng; lưu công thức cho quán (có thể công khai vào Top cộng đồng).

## Các file trong gói
| File / thư mục | Vai trò |
|---|---|
| `CustomDrink/` | Toàn bộ backend: Controllers (API `/api/custom-drinks/...`), Services, Repositories, Entities, DTO, Infrastructure, `Sql/CustomDrink_Schema.sql` |
| `Controllers/TuyChinhController.cs` | Trang cho khách: `/TuyChinh`, `/TuyChinh/Tao/{id}`, `/TuyChinh/GioHang`, `/TuyChinh/CongThuc` |
| `Views/TuyChinh/*.cshtml` | Giao diện chọn món nền, tạo món, giỏ món tự tạo, công thức đã lưu |
| `wwwroot/js/tuy-chinh.js`, `wwwroot/css/tuy-chinh.css` | Script và style |

## Gắn vào dự án (các file dùng chung, không nằm trong gói)
1. `Program.cs`, thêm trước `AddDistributedMemoryCache()`:
   `builder.Services.AddCustomDrinkFeature(builder.Configuration);`
2. `appsettings.json`, thêm:
   ```json
   "CustomDrink": { "AdminApiKey": "doi-thanh-khoa-bi-mat", "EnforceStock": false, "MaxSavedRecipesPerCustomer": 50 }
   ```
3. `Models/AppDbContext.cs` phải có `partial void OnModelCreatingPartial(ModelBuilder)` (gói CustomDrink móc vào đây).
4. `Views/Shared/_KhachLayout.cshtml`: nạp `tuy-chinh.css` trong head, thêm `@await RenderSectionAsync("Styles", required: false)` và `@await RenderSectionAsync("Scripts", required: false)`, thêm nút `<a class="tc-nut-header" asp-controller="TuyChinh" asp-action="Index">Tự tạo món</a>` cạnh nút giỏ hàng.
5. `Views/Menu/Index.cshtml`: banner `<a class="tc-banner" asp-controller="TuyChinh" asp-action="Index">...`. `Views/Menu/ChiTiet.cshtml`: nút `Tự tạo món theo ý bạn` (hiện khi `ViewBag.TuyChinh == true`, đặt ở `MenuController.ChiTiet`). `Views/GioHang/Index.cshtml`: link sang giỏ món tự tạo.
6. Hiển thị mô tả tùy chỉnh (`Chitietdon.Ghichu`) ở các view đơn: nhân viên, trang cảm ơn, theo dõi đơn, thanh toán; dashboard trả thêm `ghiChuMon`.

## Phụ thuộc
- Gói **1_Kho**: `CustomDrinkRepositories.PlaceAsync` gọi `KhoHang.ThayDoiAsync` để trừ tồn món nền.
- Bảng `sanpham`, `donhang`, `chitietdon`, `nguyenlieu`, `lichsukho` có sẵn.

## Chạy
Chạy `CustomDrink/Sql/CustomDrink_Schema.sql` trong SSMS (database `QuanCafe`), build, quét QR bàn -> "Tự tạo món".
API admin (`/api/custom-drinks/admin/...`) cần header `X-Admin-Key`, hoặc chạy ở môi trường Development.
