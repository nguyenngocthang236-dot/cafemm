using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanCafe.Models;

namespace QuanCafe.Controllers;

/// <summary>
/// Giao diện khách cho tính năng "Tự tạo món". Kế thừa KhachController nên cũng bắt buộc quét QR trước.
/// Dữ liệu và nghiệp vụ nằm ở các API /api/custom-drinks/... (thư mục CustomDrink); controller này chỉ trả trang HTML.
/// </summary>
public class TuyChinhController : KhachController
{
    private readonly ILogger<TuyChinhController> _logger;

    public TuyChinhController(AppDbContext db, ILogger<TuyChinhController> logger) : base(db) => _logger = logger;

    // GET /TuyChinh  -> bước 1: chọn món nền để tự tạo đồ uống
    public async Task<IActionResult> Index()
    {
        var ds = await _db.Sanphams.AsNoTracking()
            .Where(s => s.Soluongton > 0)
            .OrderBy(s => s.Idsanpham)
            .ToListAsync();
        return View(ds);
    }

    // GET /TuyChinh/Tao/5  -> trang chọn size, đường, đá, topping cho món nền
    public async Task<IActionResult> Tao(int id)
    {
        var sp = await _db.Sanphams.AsNoTracking().FirstOrDefaultAsync(s => s.Idsanpham == id);
        if (sp == null || sp.Soluongton <= 0)
            return RedirectToAction("Index", "Menu");

        // Không nuốt lỗi âm thầm nữa: báo rõ để biết cần làm gì.
        try
        {
            var choPhep = await _db.BaseProducts.AsNoTracking().AnyAsync(b => b.Idsanpham == id && b.IsCustomizable);
            if (!choPhep)
                ViewBag.Loi = "Món này chưa được bật tính năng tự tạo. Quán cần thêm món vào bảng cd_baseproduct (chạy lại phần cuối của CustomDrink_Schema.sql hoặc gọi API admin).";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Không đọc được bảng cd_baseproduct.");
            ViewBag.Loi = "Chưa có dữ liệu tự tạo món trong database. Cần chạy file CustomDrink/Sql/CustomDrink_Schema.sql trong SSMS (database QuanCafe) rồi tải lại trang.";
        }

        return View(sp);
    }

    // GET /TuyChinh/GioHang  -> giỏ các món tự tạo + đặt hàng
    public IActionResult GioHang() => View();

    // GET /TuyChinh/CongThuc  -> công thức đã lưu + top cộng đồng
    public IActionResult CongThuc() => View();
}
