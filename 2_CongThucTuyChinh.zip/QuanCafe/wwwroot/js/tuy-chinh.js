/* tuy-chinh.js - giao diện "Tự tạo món". Gọi API /api/custom-drinks/... */
(function () {
  'use strict';
  var API = '/api/custom-drinks';

  function tien(n) { return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + 'đ'; }
  function $(root, sel) { return root.querySelector(sel); }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  var toastEl, toastTimer;
  function toast(msg, loi) {
    toastEl = toastEl || document.querySelector('[data-toast]');
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.toggle('toast--loi', !!loi);
    toastEl.classList.add('toast--hien');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('toast--hien'); }, 2800);
  }

  function goi(method, url, body) {
    var opt = { method: method, headers: { 'Accept': 'application/json' }, credentials: 'same-origin' };
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    return fetch(url, opt).then(function (res) {
      if (res.status === 204) return null;
      return res.json().catch(function () { return null; }).then(function (data) {
        if (!res.ok) {
          var msg = (data && (data.title || data.detail)) || 'Có lỗi xảy ra, bạn thử lại nhé.';
          if (res.status === 401) msg = 'Bạn cần quét QR tại bàn trước khi đặt hàng.';
          var err = new Error(msg); err.status = res.status; throw err;
        }
        return data;
      });
    });
  }

  function hienLoi(root, msg) {
    var box = $(root, '[data-tc-loi]');
    if (!box) { toast(msg, true); return; }
    box.textContent = msg || '';
    box.hidden = !msg;
  }

  // ======================= Trang tạo món =======================
  function khoiTaoTao(root) {
    var idMon = parseInt(root.dataset.id, 10);
    var ton = parseInt(root.dataset.ton, 10) || 1;
    var vung = $(root, '[data-tc-nhom]');
    var elGia = $(root, '[data-tc-gia]');
    var elMoTa = $(root, '[data-tc-mo-ta]');
    var nutThem = $(root, '[data-tc-them]');
    var elSl = $(root, '[data-tc-sl]');
    var menu = null;
    var chon = {};      // optionId -> số lượng
    var soLy = 1;
    var maxLy = Math.max(1, Math.min(20, ton));
    var yeuCau = 0;

    function tongNhom(g) {
      return g.options.reduce(function (s, o) { return s + (chon[o.id] || 0); }, 0);
    }

    function danhSachChon() {
      return Object.keys(chon).filter(function (k) { return chon[k] > 0; })
        .map(function (k) { return { optionId: parseInt(k, 10), quantity: chon[k] }; });
    }

    function veNhom(g) {
      var box = el('div', 'tc-nhom');
      var ten = el('div', 'tc-nhom__ten', g.name);
      if (g.isRequired) ten.appendChild(el('span', 'tc-nhom__bat-buoc', 'Bắt buộc'));
      else ten.appendChild(el('small', null, '(tuỳ chọn)'));
      if (g.maxSelect > 1) ten.appendChild(el('small', null, 'tối đa ' + g.maxSelect));
      box.appendChild(ten);
      if (g.description) box.appendChild(el('div', 'tc-phu', g.description));

      var ds = el('div', 'tc-lua-chon');
      var chiMot = g.maxSelect === 1;
      g.options.forEach(function (o) {
        var gia = o.extraPrice > 0 ? ' +' + tien(o.extraPrice) : '';
        if (chiMot) {
          var chip = el('button', 'tc-chip', o.name);
          chip.type = 'button';
          if (o.extraPrice > 0) chip.appendChild(el('small', null, '+' + tien(o.extraPrice)));
          chip.setAttribute('aria-pressed', chon[o.id] ? 'true' : 'false');
          chip.addEventListener('click', function () {
            var dangChon = !!chon[o.id];
            g.options.forEach(function (x) { delete chon[x.id]; });
            if (!dangChon || g.isRequired) chon[o.id] = 1;   // nhóm bắt buộc: không cho bỏ chọn hết
            capNhat();
          });
          ds.appendChild(chip);
        } else {
          var w = el('span', 'tc-topping');
          w.dataset.co = chon[o.id] ? '1' : '0';
          w.appendChild(el('span', null, o.name + gia));
          var tru = el('button', null, '−'); tru.type = 'button'; tru.setAttribute('aria-label', 'Bớt ' + o.name);
          var sl = el('span', 'tc-topping__sl', String(chon[o.id] || 0));
          var cong = el('button', null, '+'); cong.type = 'button'; cong.setAttribute('aria-label', 'Thêm ' + o.name);
          tru.disabled = !chon[o.id];
          cong.disabled = (chon[o.id] || 0) >= o.maxQuantity || tongNhom(g) >= g.maxSelect;
          tru.addEventListener('click', function () {
            if ((chon[o.id] || 0) > 0) { chon[o.id]--; if (!chon[o.id]) delete chon[o.id]; capNhat(); }
          });
          cong.addEventListener('click', function () { chon[o.id] = (chon[o.id] || 0) + 1; capNhat(); });
          w.appendChild(tru); w.appendChild(sl); w.appendChild(cong);
          ds.appendChild(w);
        }
      });
      box.appendChild(ds);
      return box;
    }

    function ve() {
      vung.textContent = '';
      menu.groups.forEach(function (g) { vung.appendChild(veNhom(g)); });
    }

    function capNhat() {
      ve();
      elSl.value = soLy;
      var id = ++yeuCau;
      goi('POST', API + '/quote', { baseProductId: idMon, selectedOptions: danhSachChon() })
        .then(function (q) {
          if (id !== yeuCau) return;
          hienLoi(root, '');
          elGia.textContent = tien(q.unitPrice * soLy);
          elMoTa.textContent = q.description || 'Chưa chọn gì thêm';
          nutThem.disabled = false;
        })
        .catch(function (e) {
          if (id !== yeuCau) return;
          nutThem.disabled = true;
          elGia.textContent = tien(menu.basePrice * soLy);
          elMoTa.textContent = e.message;   // ví dụ "Mức đường là bắt buộc."
        });
    }

    $(root, '[data-tc-tru]').addEventListener('click', function () { if (soLy > 1) { soLy--; capNhat(); } });
    $(root, '[data-tc-cong]').addEventListener('click', function () {
      if (soLy < maxLy) { soLy++; capNhat(); } else toast('Món này chỉ còn ' + ton + ' trong kho.', true);
    });

    nutThem.addEventListener('click', function () {
      nutThem.disabled = true;
      goi('POST', API + '/cart', { baseProductId: idMon, selectedOptions: danhSachChon(), quantity: soLy })
        .then(function () { window.location.href = root.dataset.urlGio; })
        .catch(function (e) { hienLoi(root, e.message); nutThem.disabled = false; });
    });

    $(root, '[data-tc-luu]').addEventListener('click', function () {
      var ten = $(root, '[data-tc-ten]').value.trim();
      if (!ten) { toast('Bạn đặt tên công thức nhé.', true); return; }
      goi('POST', API + '/recipes', {
        name: ten, note: null, isPublic: $(root, '[data-tc-cong-khai]').checked,
        baseProductId: idMon, selectedOptions: danhSachChon()
      }).then(function () { toast('Đã lưu công thức cho quán.'); })
        .catch(function (e) { toast(e.message, true); });
    });

    goi('GET', API + '/builder/' + idMon).then(function (m) {
      menu = m;
      m.groups.forEach(function (g) {
        g.options.forEach(function (o) { if (o.isDefault) chon[o.id] = 1; });
      });
      capNhat();
    }).catch(function (e) {
      vung.textContent = '';
      hienLoi(root, e.message);
    });
  }

  // ======================= Giỏ món tự tạo =======================
  function khoiTaoGio(root) {
    var ds = $(root, '[data-tc-ds]');
    var phanDat = $(root, '[data-tc-thanh-toan]');
    var nutDat = $(root, '[data-tc-dat]');

    function ve(cart) {
      ds.textContent = '';
      if (!cart.lines.length) {
        ds.appendChild(el('p', 'tc-phu', 'Chưa có món tự tạo nào trong giỏ.'));
        phanDat.hidden = true;
        return;
      }
      var coLoi = false;
      cart.lines.forEach(function (l) {
        var the = el('div', 'tc-the');
        var trai = el('div');
        trai.appendChild(el('div', 'tc-the__ten', (l.quote ? l.quote.baseProductName : 'Món không còn hợp lệ') + ' x' + l.quantity));
        trai.appendChild(el('div', 'tc-the__mo-ta', l.quote ? (l.quote.description || 'Không thêm gì') : l.problem));
        if (l.problem) coLoi = true;
        var phai = el('div', 'tc-the__phai');
        phai.appendChild(el('div', 'tc-the__gia', tien(l.lineTotal)));
        var xoa = el('button', 'tc-the__nut tc-the__nut--xoa', 'Xóa'); xoa.type = 'button';
        xoa.addEventListener('click', function () {
          goi('DELETE', API + '/cart/' + l.customRecipeId).then(ve).catch(function (e) { toast(e.message, true); });
        });
        phai.appendChild(xoa);
        the.appendChild(trai); the.appendChild(phai);
        ds.appendChild(the);
      });
      $(root, '[data-tc-tong-sl]').textContent = cart.totalQuantity;
      $(root, '[data-tc-tong-tien]').textContent = tien(cart.totalPrice);
      phanDat.hidden = false;
      nutDat.disabled = coLoi;
      if (coLoi) hienLoi(root, 'Có món không còn hợp lệ, bạn xóa món đó rồi đặt lại nhé.'); else hienLoi(root, '');
    }

    nutDat.addEventListener('click', function () {
      nutDat.disabled = true;
      goi('POST', API + '/cart/checkout', { note: $(root, '[data-tc-ghi-chu]').value })
        .then(function (r) {
          window.location.href = root.dataset.urlThanhCong + '?maDon=' + encodeURIComponent(r.orderCode);
        })
        .catch(function (e) { hienLoi(root, e.message); nutDat.disabled = false; });
    });

    goi('GET', API + '/cart').then(ve).catch(function (e) { hienLoi(root, e.message); });
  }

  // ======================= Công thức đã lưu + top cộng đồng =======================
  function moTaOptions(opts) {
    return opts.map(function (o) { return o.optionName + (o.quantity > 1 ? ' x' + o.quantity : ''); }).join(', ');
  }

  function khoiTaoCongThuc(root) {
    var ds = $(root, '[data-tc-ds]');
    var top = $(root, '[data-tc-top]');

    function veDs() {
      goi('GET', API + '/recipes?page=1&pageSize=50').then(function (p) {
        ds.textContent = '';
        if (!p.items.length) { ds.appendChild(el('p', 'tc-phu', 'Bạn chưa lưu công thức nào. Hãy tạo món rồi bấm "Lưu thành công thức".')); return; }
        p.items.forEach(function (r) {
          var the = el('div', 'tc-the');
          var trai = el('div');
          trai.appendChild(el('div', 'tc-the__ten', r.name));
          trai.appendChild(el('div', 'tc-the__mo-ta', r.baseProductName + (r.options.length ? ': ' + moTaOptions(r.options) : '')));
          trai.appendChild(el('div', 'tc-the__mo-ta', 'Đã đặt ' + r.orderCount + ' lần'));
          var phai = el('div', 'tc-the__phai');
          phai.appendChild(el('div', 'tc-the__gia', tien(r.currentUnitPrice)));
          if (r.isAvailable) {
            var dat = el('button', 'tc-the__nut', 'Đặt lại'); dat.type = 'button';
            dat.addEventListener('click', function () {
              goi('POST', API + '/recipes/' + r.id + '/add-to-cart', { quantity: 1 })
                .then(function () { window.location.href = root.dataset.urlGio; })
                .catch(function (e) { hienLoi(root, e.message); });
            });
            phai.appendChild(dat);
          } else {
            phai.appendChild(el('span', 'tc-the__mo-ta', 'Tạm không đặt được'));
          }
          var xoa = el('button', 'tc-the__nut tc-the__nut--xoa', 'Xóa'); xoa.type = 'button';
          xoa.addEventListener('click', function () {
            if (!window.confirm('Xóa công thức "' + r.name + '"?')) return;
            goi('DELETE', API + '/recipes/' + r.id).then(veDs).catch(function (e) { hienLoi(root, e.message); });
          });
          phai.appendChild(xoa);
          the.appendChild(trai); the.appendChild(phai);
          ds.appendChild(the);
        });
      }).catch(function (e) { ds.textContent = ''; hienLoi(root, e.message); });
    }

    function veTop() {
      goi('GET', API + '/community/top?take=10').then(function (items) {
        top.textContent = '';
        if (!items.length) { top.appendChild(el('p', 'tc-phu', 'Chưa có công thức công khai nào.')); return; }
        items.forEach(function (r) {
          var the = el('div', 'tc-the');
          var trai = el('div');
          trai.appendChild(el('div', 'tc-the__ten', r.name));
          trai.appendChild(el('div', 'tc-the__mo-ta', r.baseProductName + (r.options.length ? ': ' + moTaOptions(r.options) : '')));
          trai.appendChild(el('div', 'tc-the__mo-ta', r.orderCount + ' lượt đặt'));
          var phai = el('div', 'tc-the__phai');
          phai.appendChild(el('div', 'tc-the__gia', tien(r.currentUnitPrice)));
          var thu = el('a', 'tc-the__nut', 'Tạo món này');
          thu.href = root.dataset.urlTao + '/' + r.baseProductId;
          phai.appendChild(thu);
          the.appendChild(trai); the.appendChild(phai);
          top.appendChild(the);
        });
      }).catch(function () { top.textContent = ''; });
    }

    veDs(); veTop();
  }

  document.addEventListener('DOMContentLoaded', function () {
    var root = document.querySelector('[data-tc]');
    if (!root) return;
    var loai = root.dataset.tc;
    if (loai === 'tao') khoiTaoTao(root);
    else if (loai === 'gio') khoiTaoGio(root);
    else if (loai === 'cong-thuc') khoiTaoCongThuc(root);
  });
})();
