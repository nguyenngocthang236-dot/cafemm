using QuanCafe.Models;

namespace QuanCafe.CustomDrink.Entities;

// Toàn bộ entity của tính năng "Tự sáng tạo món uống" nằm trong namespace riêng
// QuanCafe.CustomDrink.Entities và map vào các bảng có tiền tố "cd_" nên không
// trùng tên với bất kỳ lớp / bảng nào của code gốc (Sanpham, Donhang, ...).

/// <summary>Khách hàng ẩn danh được nhận diện bằng cookie (chưa có hệ thống đăng nhập). Có thể thay bằng tài khoản thật sau này.</summary>
public class CustomerProfile
{
    public Guid Id { get; set; }
    public string? DisplayName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime LastSeenAt { get; set; } = DateTime.Now;
}

/// <summary>Món nền: mở rộng 1-1 cho một dòng trong bảng sanpham, cho biết món đó có cho phép tuỳ chỉnh hay không.</summary>
public class BaseProduct
{
    /// <summary>Vừa là khoá chính vừa là khoá ngoại tới sanpham.idsanpham.</summary>
    public int Idsanpham { get; set; }
    public bool IsCustomizable { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public Sanpham Sanpham { get; set; } = null!;
    public ICollection<BaseProductOptionGroup> OptionGroupLinks { get; set; } = new List<BaseProductOptionGroup>();
}

/// <summary>Nhóm tuỳ chỉnh (Size, Mức đường, Mức đá, Loại sữa, Topping...).</summary>
public class OptionGroup
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string? Description { get; set; }

    /// <summary>Bắt buộc phải chọn ít nhất 1 lựa chọn trong nhóm.</summary>
    public bool IsRequired { get; set; }

    /// <summary>Tổng số lượng tối thiểu (áp dụng khi đã chọn, hoặc luôn áp dụng nếu nhóm bắt buộc).</summary>
    public int MinSelect { get; set; }

    /// <summary>Tổng số lượng tối đa của tất cả lựa chọn trong nhóm.</summary>
    public int MaxSelect { get; set; } = 1;

    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;

    /// <summary>Số lượng tối thiểu thực tế: nhóm bắt buộc thì luôn &gt;= 1.</summary>
    public int EffectiveMin => IsRequired ? Math.Max(MinSelect, 1) : MinSelect;

    public ICollection<DrinkOption> Options { get; set; } = new List<DrinkOption>();
    public ICollection<BaseProductOptionGroup> BaseProductLinks { get; set; } = new List<BaseProductOptionGroup>();
}

/// <summary>Bảng nối: món nền nào được dùng nhóm tuỳ chỉnh nào.</summary>
public class BaseProductOptionGroup
{
    public int Idsanpham { get; set; }
    public int OptionGroupId { get; set; }
    public int SortOrder { get; set; }

    public BaseProduct BaseProduct { get; set; } = null!;
    public OptionGroup OptionGroup { get; set; } = null!;
}

/// <summary>Một lựa chọn trong nhóm (Size L, 50% đường, Trân châu...). Đặt tên DrinkOption để không nhầm với Options pattern của .NET.</summary>
public class DrinkOption
{
    public int Id { get; set; }
    public int OptionGroupId { get; set; }
    public string Name { get; set; } = null!;

    /// <summary>Giá cộng thêm cho MỖI đơn vị của lựa chọn này.</summary>
    public decimal ExtraPrice { get; set; }

    /// <summary>Số lượng tối đa của riêng lựa chọn này (ví dụ tối đa 2 phần trân châu).</summary>
    public int MaxQuantity { get; set; } = 1;

    public bool IsDefault { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }

    public OptionGroup OptionGroup { get; set; } = null!;
    public ICollection<OptionIngredient> Ingredients { get; set; } = new List<OptionIngredient>();
}

/// <summary>Ánh xạ lựa chọn -> nguyên liệu trong kho (bảng nguyenlieu của code gốc) để trừ kho tự động.</summary>
public class OptionIngredient
{
    public int OptionId { get; set; }
    public int Idnguyenlieu { get; set; }

    /// <summary>Lượng nguyên liệu tiêu hao cho MỖI đơn vị lựa chọn (theo đơn vị tính của nguyên liệu).</summary>
    public decimal ConsumptionQuantity { get; set; }

    public DrinkOption Option { get; set; } = null!;
    public Nguyenlieu Nguyenlieu { get; set; } = null!;
}

/// <summary>
/// Một "cấu hình món" duy nhất (món nền + tập lựa chọn). Hai khách chọn giống hệt nhau dùng chung một
/// CustomRecipe (nhận diện bằng ConfigHash) nên số lượt đặt được cộng dồn để thống kê cộng đồng.
/// </summary>
public class CustomRecipe
{
    public int Id { get; set; }
    public int Idsanpham { get; set; }
    public string ConfigHash { get; set; } = null!;

    /// <summary>Tổng số ly đã được đặt theo cấu hình này.</summary>
    public int OrderCount { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime? LastOrderedAt { get; set; }

    public Sanpham Sanpham { get; set; } = null!;
    public ICollection<CustomRecipeDetail> Details { get; set; } = new List<CustomRecipeDetail>();
    public ICollection<UserSavedRecipe> SavedBy { get; set; } = new List<UserSavedRecipe>();
}

public class CustomRecipeDetail
{
    public int Id { get; set; }
    public int CustomRecipeId { get; set; }
    public int OptionId { get; set; }
    public int Quantity { get; set; } = 1;

    public CustomRecipe CustomRecipe { get; set; } = null!;
    public DrinkOption Option { get; set; } = null!;
}

/// <summary>Công thức khách đã lưu kèm tên riêng và ghi chú.</summary>
public class UserSavedRecipe
{
    public int Id { get; set; }
    public Guid CustomerId { get; set; }
    public int CustomRecipeId { get; set; }
    public string Name { get; set; } = null!;
    public string? Note { get; set; }

    /// <summary>true = cho phép hiển thị trong danh sách gợi ý cộng đồng.</summary>
    public bool IsPublic { get; set; }

    /// <summary>Số ly khách này đã đặt từ công thức đã lưu.</summary>
    public int OrderCount { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    public CustomerProfile Customer { get; set; } = null!;
    public CustomRecipe CustomRecipe { get; set; } = null!;
}
