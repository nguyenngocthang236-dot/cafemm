/*
  Tính năng "Tự sáng tạo món uống & Lưu công thức" - tạo bảng mới cho database QuanCafe.

  - Chỉ THÊM bảng mới có tiền tố cd_; không sửa / xoá bất kỳ bảng nào của hệ thống cũ.
  - Chạy lại nhiều lần vẫn an toàn (kiểm tra OBJECT_ID trước khi tạo, seed chỉ chạy khi bảng nhóm còn trống).
  - Tên cột trùng đúng tên property trong CustomDrink/Entities để khớp cấu hình Fluent API.
  - SAO LƯU database trước khi chạy.

  LƯU Ý: chọn MỘT cách tạo bảng, đừng dùng cả hai:
    (a) chạy file này trong SSMS, hoặc
    (b) dotnet ef migrations add CustomDrink  ->  dotnet ef database update
        (khi đó bỏ qua phần tạo bảng trong file này, chỉ dùng phần "SEED" ở cuối nếu muốn dữ liệu mẫu).
*/
USE [QuanCafe];
GO
SET NOCOUNT ON;
GO

-- ============================== BẢNG ==============================

IF OBJECT_ID(N'dbo.cd_customer', N'U') IS NULL
CREATE TABLE dbo.cd_customer (
    Id          uniqueidentifier NOT NULL CONSTRAINT PK_cd_customer PRIMARY KEY,
    DisplayName nvarchar(100)    NULL,
    CreatedAt   datetime         NOT NULL CONSTRAINT DF_cd_customer_CreatedAt DEFAULT (getdate()),
    LastSeenAt  datetime         NOT NULL CONSTRAINT DF_cd_customer_LastSeenAt DEFAULT (getdate())
);
GO

IF OBJECT_ID(N'dbo.cd_baseproduct', N'U') IS NULL
CREATE TABLE dbo.cd_baseproduct (
    Idsanpham      int      NOT NULL CONSTRAINT PK_cd_baseproduct PRIMARY KEY,
    IsCustomizable bit      NOT NULL CONSTRAINT DF_cd_baseproduct_IsCustomizable DEFAULT (1),
    CreatedAt      datetime NOT NULL CONSTRAINT DF_cd_baseproduct_CreatedAt DEFAULT (getdate()),
    CONSTRAINT FK_cd_baseproduct_sanpham FOREIGN KEY (Idsanpham) REFERENCES dbo.sanpham (idsanpham)
);
GO

IF OBJECT_ID(N'dbo.cd_optiongroup', N'U') IS NULL
CREATE TABLE dbo.cd_optiongroup (
    Id          int IDENTITY(1,1) NOT NULL CONSTRAINT PK_cd_optiongroup PRIMARY KEY,
    Name        nvarchar(100) NOT NULL,
    Description nvarchar(255) NULL,
    IsRequired  bit NOT NULL CONSTRAINT DF_cd_optiongroup_IsRequired DEFAULT (0),
    MinSelect   int NOT NULL CONSTRAINT DF_cd_optiongroup_MinSelect DEFAULT (0),
    MaxSelect   int NOT NULL CONSTRAINT DF_cd_optiongroup_MaxSelect DEFAULT (1),
    SortOrder   int NOT NULL CONSTRAINT DF_cd_optiongroup_SortOrder DEFAULT (0),
    IsActive    bit NOT NULL CONSTRAINT DF_cd_optiongroup_IsActive DEFAULT (1),
    CONSTRAINT CK_cd_optiongroup_range CHECK (MinSelect >= 0 AND MaxSelect >= 1 AND MinSelect <= MaxSelect)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_optiongroup_Name' AND object_id = OBJECT_ID(N'dbo.cd_optiongroup'))
    CREATE UNIQUE INDEX IX_cd_optiongroup_Name ON dbo.cd_optiongroup (Name);
GO

IF OBJECT_ID(N'dbo.cd_baseproduct_optiongroup', N'U') IS NULL
CREATE TABLE dbo.cd_baseproduct_optiongroup (
    Idsanpham     int NOT NULL,
    OptionGroupId int NOT NULL,
    SortOrder     int NOT NULL CONSTRAINT DF_cd_bpog_SortOrder DEFAULT (0),
    CONSTRAINT PK_cd_baseproduct_optiongroup PRIMARY KEY (Idsanpham, OptionGroupId),
    CONSTRAINT FK_cd_bpog_baseproduct FOREIGN KEY (Idsanpham)     REFERENCES dbo.cd_baseproduct (Idsanpham) ON DELETE CASCADE,
    CONSTRAINT FK_cd_bpog_optiongroup FOREIGN KEY (OptionGroupId) REFERENCES dbo.cd_optiongroup (Id)       ON DELETE CASCADE
);
GO

IF OBJECT_ID(N'dbo.cd_option', N'U') IS NULL
CREATE TABLE dbo.cd_option (
    Id            int IDENTITY(1,1) NOT NULL CONSTRAINT PK_cd_option PRIMARY KEY,
    OptionGroupId int NOT NULL,
    Name          nvarchar(100) NOT NULL,
    ExtraPrice    decimal(12,0) NOT NULL CONSTRAINT DF_cd_option_ExtraPrice DEFAULT (0),
    MaxQuantity   int NOT NULL CONSTRAINT DF_cd_option_MaxQuantity DEFAULT (1),
    IsDefault     bit NOT NULL CONSTRAINT DF_cd_option_IsDefault DEFAULT (0),
    IsActive      bit NOT NULL CONSTRAINT DF_cd_option_IsActive DEFAULT (1),
    SortOrder     int NOT NULL CONSTRAINT DF_cd_option_SortOrder DEFAULT (0),
    CONSTRAINT FK_cd_option_optiongroup FOREIGN KEY (OptionGroupId) REFERENCES dbo.cd_optiongroup (Id) ON DELETE CASCADE,
    CONSTRAINT CK_cd_option_values CHECK (ExtraPrice >= 0 AND MaxQuantity >= 1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_option_Group_Name' AND object_id = OBJECT_ID(N'dbo.cd_option'))
    CREATE UNIQUE INDEX IX_cd_option_Group_Name ON dbo.cd_option (OptionGroupId, Name);
GO

IF OBJECT_ID(N'dbo.cd_option_ingredient', N'U') IS NULL
CREATE TABLE dbo.cd_option_ingredient (
    OptionId            int NOT NULL,
    Idnguyenlieu        int NOT NULL,
    ConsumptionQuantity decimal(12,2) NOT NULL,
    CONSTRAINT PK_cd_option_ingredient PRIMARY KEY (OptionId, Idnguyenlieu),
    CONSTRAINT FK_cd_oi_option     FOREIGN KEY (OptionId)     REFERENCES dbo.cd_option (Id) ON DELETE CASCADE,
    CONSTRAINT FK_cd_oi_nguyenlieu FOREIGN KEY (Idnguyenlieu) REFERENCES dbo.nguyenlieu (idnguyenlieu),
    CONSTRAINT CK_cd_oi_qty CHECK (ConsumptionQuantity > 0)
);
GO

IF OBJECT_ID(N'dbo.cd_customrecipe', N'U') IS NULL
CREATE TABLE dbo.cd_customrecipe (
    Id            int IDENTITY(1,1) NOT NULL CONSTRAINT PK_cd_customrecipe PRIMARY KEY,
    Idsanpham     int NOT NULL,
    ConfigHash    varchar(64) NOT NULL,
    OrderCount    int NOT NULL CONSTRAINT DF_cd_customrecipe_OrderCount DEFAULT (0),
    CreatedAt     datetime NOT NULL CONSTRAINT DF_cd_customrecipe_CreatedAt DEFAULT (getdate()),
    LastOrderedAt datetime NULL,
    CONSTRAINT FK_cd_customrecipe_sanpham FOREIGN KEY (Idsanpham) REFERENCES dbo.sanpham (idsanpham)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_customrecipe_ConfigHash' AND object_id = OBJECT_ID(N'dbo.cd_customrecipe'))
    CREATE UNIQUE INDEX IX_cd_customrecipe_ConfigHash ON dbo.cd_customrecipe (ConfigHash);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_customrecipe_OrderCount' AND object_id = OBJECT_ID(N'dbo.cd_customrecipe'))
    CREATE INDEX IX_cd_customrecipe_OrderCount ON dbo.cd_customrecipe (OrderCount);
GO

IF OBJECT_ID(N'dbo.cd_customrecipedetail', N'U') IS NULL
CREATE TABLE dbo.cd_customrecipedetail (
    Id             int IDENTITY(1,1) NOT NULL CONSTRAINT PK_cd_customrecipedetail PRIMARY KEY,
    CustomRecipeId int NOT NULL,
    OptionId       int NOT NULL,
    Quantity       int NOT NULL CONSTRAINT DF_cd_crd_Quantity DEFAULT (1),
    CONSTRAINT FK_cd_crd_recipe FOREIGN KEY (CustomRecipeId) REFERENCES dbo.cd_customrecipe (Id) ON DELETE CASCADE,
    CONSTRAINT FK_cd_crd_option FOREIGN KEY (OptionId)       REFERENCES dbo.cd_option (Id),
    CONSTRAINT CK_cd_crd_qty CHECK (Quantity >= 1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_crd_Recipe_Option' AND object_id = OBJECT_ID(N'dbo.cd_customrecipedetail'))
    CREATE UNIQUE INDEX IX_cd_crd_Recipe_Option ON dbo.cd_customrecipedetail (CustomRecipeId, OptionId);
GO

IF OBJECT_ID(N'dbo.cd_usersavedrecipe', N'U') IS NULL
CREATE TABLE dbo.cd_usersavedrecipe (
    Id             int IDENTITY(1,1) NOT NULL CONSTRAINT PK_cd_usersavedrecipe PRIMARY KEY,
    CustomerId     uniqueidentifier NOT NULL,
    CustomRecipeId int NOT NULL,
    Name           nvarchar(100) NOT NULL,
    Note           nvarchar(500) NULL,
    IsPublic       bit NOT NULL CONSTRAINT DF_cd_usr_IsPublic DEFAULT (0),
    OrderCount     int NOT NULL CONSTRAINT DF_cd_usr_OrderCount DEFAULT (0),
    CreatedAt      datetime NOT NULL CONSTRAINT DF_cd_usr_CreatedAt DEFAULT (getdate()),
    UpdatedAt      datetime NOT NULL CONSTRAINT DF_cd_usr_UpdatedAt DEFAULT (getdate()),
    CONSTRAINT FK_cd_usr_customer FOREIGN KEY (CustomerId)     REFERENCES dbo.cd_customer (Id) ON DELETE CASCADE,
    CONSTRAINT FK_cd_usr_recipe   FOREIGN KEY (CustomRecipeId) REFERENCES dbo.cd_customrecipe (Id)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_usr_Customer_Recipe' AND object_id = OBJECT_ID(N'dbo.cd_usersavedrecipe'))
    CREATE UNIQUE INDEX IX_cd_usr_Customer_Recipe ON dbo.cd_usersavedrecipe (CustomerId, CustomRecipeId);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_usr_Customer_Name' AND object_id = OBJECT_ID(N'dbo.cd_usersavedrecipe'))
    CREATE UNIQUE INDEX IX_cd_usr_Customer_Name ON dbo.cd_usersavedrecipe (CustomerId, Name);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_cd_usr_Public_Recipe' AND object_id = OBJECT_ID(N'dbo.cd_usersavedrecipe'))
    CREATE INDEX IX_cd_usr_Public_Recipe ON dbo.cd_usersavedrecipe (IsPublic, CustomRecipeId);
GO

-- ============================== SEED (dữ liệu mẫu, chỉ chạy khi chưa có nhóm nào) ==============================
-- Có thể bỏ qua phần này và tự tạo bằng API admin: POST /api/custom-drinks/admin/option-groups ...

IF NOT EXISTS (SELECT 1 FROM dbo.cd_optiongroup)
BEGIN
    BEGIN TRAN;

    INSERT dbo.cd_optiongroup (Name, Description, IsRequired, MinSelect, MaxSelect, SortOrder) VALUES
        (N'Size',          N'Chọn kích cỡ ly',            1, 1, 1, 1),
        (N'Mức đường',     N'Độ ngọt của món',            1, 1, 1, 2),
        (N'Mức đá',        N'Lượng đá',                   1, 1, 1, 3),
        (N'Loại sữa',      N'Đổi loại sữa (không bắt buộc)', 0, 0, 1, 4),
        (N'Topping/Extra', N'Tối đa 3 phần topping',      0, 0, 3, 5);

    DECLARE @gSize int  = (SELECT Id FROM dbo.cd_optiongroup WHERE Name = N'Size');
    DECLARE @gSugar int = (SELECT Id FROM dbo.cd_optiongroup WHERE Name = N'Mức đường');
    DECLARE @gIce int   = (SELECT Id FROM dbo.cd_optiongroup WHERE Name = N'Mức đá');
    DECLARE @gMilk int  = (SELECT Id FROM dbo.cd_optiongroup WHERE Name = N'Loại sữa');
    DECLARE @gTop int   = (SELECT Id FROM dbo.cd_optiongroup WHERE Name = N'Topping/Extra');

    INSERT dbo.cd_option (OptionGroupId, Name, ExtraPrice, MaxQuantity, IsDefault, SortOrder) VALUES
        (@gSize,  N'Size S', 0,     1, 0, 1),
        (@gSize,  N'Size M', 5000,  1, 1, 2),
        (@gSize,  N'Size L', 10000, 1, 0, 3),
        (@gSugar, N'0%',   0, 1, 0, 1),
        (@gSugar, N'30%',  0, 1, 0, 2),
        (@gSugar, N'50%',  0, 1, 0, 3),
        (@gSugar, N'100%', 0, 1, 1, 4),
        (@gIce,   N'Không đá',   0, 1, 0, 1),
        (@gIce,   N'Ít đá',      0, 1, 0, 2),
        (@gIce,   N'Đá bình thường', 0, 1, 1, 3),
        (@gMilk,  N'Sữa tươi',     0,    1, 1, 1),
        (@gMilk,  N'Sữa hạt',      8000, 1, 0, 2),
        (@gMilk,  N'Sữa tách béo', 5000, 1, 0, 3),
        (@gTop,   N'Trân châu',            7000,  2, 0, 1),
        (@gTop,   N'Cream cheese',         10000, 1, 0, 2),
        (@gTop,   N'Extra Espresso Shot',  12000, 2, 0, 3);

    COMMIT;
END
GO

-- Cho phép tuỳ chỉnh MỌI món đang bán và gán tất cả nhóm mẫu (chỉnh lại sau bằng
-- PUT /api/custom-drinks/admin/base-products/{id} nếu một số món, ví dụ bánh ngọt, không nên tuỳ chỉnh).
-- Bỏ đoạn này nếu bạn muốn tự chọn món nền ngay từ đầu.
IF NOT EXISTS (SELECT 1 FROM dbo.cd_baseproduct)
   AND EXISTS (SELECT 1 FROM dbo.cd_optiongroup)
BEGIN
    BEGIN TRAN;

    INSERT dbo.cd_baseproduct (Idsanpham)
    SELECT idsanpham FROM dbo.sanpham WHERE conhang = 1;

    INSERT dbo.cd_baseproduct_optiongroup (Idsanpham, OptionGroupId, SortOrder)
    SELECT b.Idsanpham, g.Id, g.SortOrder
    FROM dbo.cd_baseproduct AS b CROSS JOIN dbo.cd_optiongroup AS g;

    COMMIT;
END
GO

-- Kiểm tra nhanh
SELECT g.Name AS NhomTuyChon, g.IsRequired, g.MinSelect, g.MaxSelect, COUNT(o.Id) AS SoLuaChon
FROM dbo.cd_optiongroup AS g LEFT JOIN dbo.cd_option AS o ON o.OptionGroupId = g.Id
GROUP BY g.Name, g.IsRequired, g.MinSelect, g.MaxSelect, g.SortOrder
ORDER BY g.SortOrder;
GO
