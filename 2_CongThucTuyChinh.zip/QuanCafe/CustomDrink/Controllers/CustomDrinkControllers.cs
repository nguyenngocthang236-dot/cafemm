using Microsoft.AspNetCore.Mvc;
using QuanCafe.CustomDrink.Dtos;
using QuanCafe.CustomDrink.Exceptions;
using QuanCafe.CustomDrink.Infrastructure;
using QuanCafe.CustomDrink.Services;

namespace QuanCafe.CustomDrink.Controllers;

// Tất cả route nằm dưới "api/custom-drinks/..." nên không trùng với "api/donhang", "api/sanpham",
// "Menu/Dashboard" hay route mặc định {controller}/{action} của code gốc.

/// <summary>Lớp cha: [ApiController] + bộ lọc lỗi riêng (400/404/409/422 chuẩn ProblemDetails).</summary>
[ApiController]
[ServiceFilter(typeof(CustomDrinkExceptionFilter))]
public abstract class CustomDrinkApiController : ControllerBase
{
}

// ============================================================================================
// A. Quản trị danh mục tuỳ chỉnh (Admin)
// ============================================================================================
[Route("api/custom-drinks/admin")]
[ServiceFilter(typeof(AdminApiKeyFilter))]
public sealed class CustomDrinkAdminController : CustomDrinkApiController
{
    private readonly IMenuOptionAdminService _admin;

    public CustomDrinkAdminController(IMenuOptionAdminService admin) => _admin = admin;

    [HttpGet("option-groups")]
    public async Task<ActionResult<IReadOnlyList<OptionGroupDto>>> ListGroups(CancellationToken ct) =>
        Ok(await _admin.ListGroupsAsync(ct));

    [HttpGet("option-groups/{id:int}", Name = "GetOptionGroup")]
    public async Task<ActionResult<OptionGroupDto>> GetGroup(int id, CancellationToken ct) =>
        Ok(await _admin.GetGroupAsync(id, ct));

    [HttpPost("option-groups")]
    public async Task<ActionResult<OptionGroupDto>> CreateGroup(UpsertOptionGroupRequest request, CancellationToken ct)
    {
        var created = await _admin.CreateGroupAsync(request, ct);
        return CreatedAtRoute("GetOptionGroup", new { id = created.Id }, created);
    }

    [HttpPut("option-groups/{id:int}")]
    public async Task<ActionResult<OptionGroupDto>> UpdateGroup(int id, UpsertOptionGroupRequest request, CancellationToken ct) =>
        Ok(await _admin.UpdateGroupAsync(id, request, ct));

    [HttpDelete("option-groups/{id:int}")]
    public async Task<ActionResult<DeleteResultDto>> DeleteGroup(int id, CancellationToken ct) =>
        Ok(await _admin.DeleteGroupAsync(id, ct));

    [HttpPost("option-groups/{groupId:int}/options")]
    public async Task<ActionResult<OptionDto>> CreateOption(int groupId, UpsertOptionRequest request, CancellationToken ct)
    {
        var created = await _admin.CreateOptionAsync(groupId, request, ct);
        return CreatedAtRoute("GetOptionGroup", new { id = groupId }, created);
    }

    [HttpPut("options/{id:int}")]
    public async Task<ActionResult<OptionDto>> UpdateOption(int id, UpsertOptionRequest request, CancellationToken ct) =>
        Ok(await _admin.UpdateOptionAsync(id, request, ct));

    [HttpDelete("options/{id:int}")]
    public async Task<ActionResult<DeleteResultDto>> DeleteOption(int id, CancellationToken ct) =>
        Ok(await _admin.DeleteOptionAsync(id, ct));

    /// <summary>Ánh xạ lựa chọn -> nguyên liệu trong kho (IngredientId + ConsumptionQuantity) để trừ kho tự động.</summary>
    [HttpPut("options/{id:int}/ingredients")]
    public async Task<ActionResult<OptionDto>> SetIngredients(int id, SetIngredientMappingRequest request, CancellationToken ct) =>
        Ok(await _admin.SetIngredientMappingAsync(id, request, ct));

    [HttpGet("base-products")]
    public async Task<ActionResult<IReadOnlyList<BaseProductDto>>> ListBaseProducts(CancellationToken ct) =>
        Ok(await _admin.ListBaseProductsAsync(ct));

    [HttpPut("base-products/{productId:int}")]
    public async Task<ActionResult<BaseProductDto>> ConfigureBaseProduct(int productId, ConfigureBaseProductRequest request, CancellationToken ct) =>
        Ok(await _admin.ConfigureBaseProductAsync(productId, request, ct));
}

// ============================================================================================
// B. Trình tạo món + giỏ hàng + đặt hàng (Khách hàng)
// ============================================================================================
[Route("api/custom-drinks")]
public sealed class DrinkBuilderController : CustomDrinkApiController
{
    private readonly IDrinkBuilderService _builder;
    private readonly ICustomOrderService _orders;
    private readonly ICurrentCustomerAccessor _customer;

    public DrinkBuilderController(IDrinkBuilderService builder, ICustomOrderService orders, ICurrentCustomerAccessor customer)
    {
        _builder = builder;
        _orders = orders;
        _customer = customer;
    }

    /// <summary>Các nhóm tuỳ chỉnh + lựa chọn khách được chọn cho món nền (để dựng giao diện).</summary>
    [HttpGet("builder/{baseProductId:int}")]
    public async Task<ActionResult<BuilderMenuDto>> GetBuilder(int baseProductId, CancellationToken ct) =>
        Ok(await _builder.GetBuilderMenuAsync(baseProductId, ct));

    /// <summary>Kiểm tra cấu hình và tính giá / định lượng cho một ly (chưa lưu gì).</summary>
    [HttpPost("quote")]
    public async Task<ActionResult<DrinkQuote>> Quote(CustomDrinkRequest request, CancellationToken ct) =>
        Ok(await _builder.QuoteAsync(request.BaseProductId, request.SelectedOptions, ct));

    [HttpGet("cart")]
    public async Task<ActionResult<CartDto>> GetCart(CancellationToken ct) =>
        Ok(await _orders.GetCartAsync(ct));

    [HttpPost("cart")]
    public async Task<ActionResult<CartDto>> AddToCart(AddToCartRequest request, CancellationToken ct) =>
        Ok(await _orders.AddToCartAsync(request, ct));

    [HttpDelete("cart/{customRecipeId:int}")]
    public async Task<ActionResult<CartDto>> RemoveFromCart(int customRecipeId, CancellationToken ct) =>
        Ok(await _orders.RemoveFromCartAsync(customRecipeId, ct));

    /// <summary>Đặt toàn bộ giỏ món tự chọn: tạo đơn, trừ kho, ghi nhận lượt đặt trong một transaction.</summary>
    [HttpPost("cart/checkout")]
    public async Task<ActionResult<CheckoutResultDto>> Checkout(CheckoutRequest? request, CancellationToken ct) =>
        Ok(await _orders.CheckoutAsync(request ?? new CheckoutRequest(null), _customer.TryGetCustomerId(), ct));
}

// ============================================================================================
// C. Công thức cá nhân đã lưu (Khách hàng)
// ============================================================================================
[Route("api/custom-drinks/recipes")]
public sealed class SavedRecipesController : CustomDrinkApiController
{
    private readonly ISavedRecipeService _recipes;
    private readonly ICustomOrderService _orders;
    private readonly ICurrentCustomerAccessor _customer;

    public SavedRecipesController(ISavedRecipeService recipes, ICustomOrderService orders, ICurrentCustomerAccessor customer)
    {
        _recipes = recipes;
        _orders = orders;
        _customer = customer;
    }

    /// <summary>Danh sách công thức đã lưu, có phân trang (page, pageSize tối đa 50) và tìm kiếm (search).</summary>
    [HttpGet]
    public async Task<ActionResult<PagedResult<SavedRecipeDto>>> List(
        [FromQuery] string? search, [FromQuery] int page = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
    {
        var customerId = _customer.TryGetCustomerId();
        if (customerId is null) // chưa lưu gì nên chưa có cookie -> danh sách rỗng, không ghi database
            return Ok(new PagedResult<SavedRecipeDto>(Array.Empty<SavedRecipeDto>(), Math.Max(page, 1), Math.Clamp(pageSize, 1, 50), 0));

        return Ok(await _recipes.ListAsync(customerId.Value, search, page, pageSize, ct));
    }

    [HttpGet("{id:int}", Name = "GetSavedRecipe")]
    public async Task<ActionResult<SavedRecipeDto>> Get(int id, CancellationToken ct)
    {
        var customerId = _customer.TryGetCustomerId()
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");
        return Ok(await _recipes.GetAsync(customerId, id, ct));
    }

    [HttpPost]
    public async Task<ActionResult<SavedRecipeDto>> Save(SaveRecipeRequest request, CancellationToken ct)
    {
        var customerId = await _customer.GetOrCreateCustomerIdAsync(ct);
        var created = await _recipes.SaveAsync(customerId, request, ct);
        return CreatedAtRoute("GetSavedRecipe", new { id = created.Id }, created);
    }

    /// <summary>Đổi tên / cập nhật ghi chú / bật tắt chia sẻ công khai. Chỉ trường nào gửi lên mới được sửa.</summary>
    [HttpPatch("{id:int}")]
    public async Task<ActionResult<SavedRecipeDto>> Update(int id, UpdateRecipeRequest request, CancellationToken ct)
    {
        var customerId = _customer.TryGetCustomerId()
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");
        return Ok(await _recipes.UpdateAsync(customerId, id, request, ct));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        var customerId = _customer.TryGetCustomerId()
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");
        await _recipes.DeleteAsync(customerId, id, ct);
        return NoContent();
    }

    /// <summary>Re-order: đưa công thức đã lưu vào giỏ món tự chọn mà không cần chọn lại từ đầu.</summary>
    [HttpPost("{id:int}/add-to-cart")]
    public async Task<ActionResult<CartDto>> AddToCart(int id, AddSavedToCartRequest? request, CancellationToken ct)
    {
        var customerId = _customer.TryGetCustomerId()
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");
        return Ok(await _orders.AddSavedRecipeToCartAsync(customerId, id, request?.Quantity ?? 1, ct));
    }
}

// ============================================================================================
// D. Thống kê & gợi ý cộng đồng
// ============================================================================================
[Route("api/custom-drinks/community")]
public sealed class CommunityRecipesController : CustomDrinkApiController
{
    private readonly ICommunityRecipeService _community;

    public CommunityRecipesController(ICommunityRecipeService community) => _community = community;

    /// <summary>Top công thức do khách tự phối được đặt nhiều nhất (chỉ gồm công thức được chủ nhân bật chia sẻ công khai).</summary>
    [HttpGet("top")]
    public async Task<ActionResult<IReadOnlyList<CommunityRecipeDto>>> Top(
        [FromQuery] int take = 10, [FromQuery] int? baseProductId = null, CancellationToken ct = default) =>
        Ok(await _community.GetTopAsync(take, baseProductId, ct));
}
