using Microsoft.EntityFrameworkCore;
using QuanCafe.CustomDrink.Entities;

// Cố ý dùng namespace QuanCafe.Models để mở rộng AppDbContext (partial class) mà KHÔNG sửa file
// AppDbContext.cs do scaffold sinh ra. Nếu scaffold lại database, file này vẫn còn nguyên vì
// AppDbContext.cs đã khai báo sẵn "partial void OnModelCreatingPartial(ModelBuilder)".
namespace QuanCafe.Models;

public partial class AppDbContext
{
    public virtual DbSet<CustomerProfile> CustomerProfiles { get; set; } = null!;
    public virtual DbSet<BaseProduct> BaseProducts { get; set; } = null!;
    public virtual DbSet<OptionGroup> OptionGroups { get; set; } = null!;
    public virtual DbSet<BaseProductOptionGroup> BaseProductOptionGroups { get; set; } = null!;
    public virtual DbSet<DrinkOption> DrinkOptions { get; set; } = null!;
    public virtual DbSet<OptionIngredient> OptionIngredients { get; set; } = null!;
    public virtual DbSet<CustomRecipe> CustomRecipes { get; set; } = null!;
    public virtual DbSet<CustomRecipeDetail> CustomRecipeDetails { get; set; } = null!;
    public virtual DbSet<UserSavedRecipe> UserSavedRecipes { get; set; } = null!;

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder) => modelBuilder.ConfigureCustomDrinkModel();
}

/// <summary>Cấu hình Fluent API cho các bảng cd_* (tên cột = tên property, khớp với file CustomDrink_Schema.sql).</summary>
public static class CustomDrinkModelConfiguration
{
    public static ModelBuilder ConfigureCustomDrinkModel(this ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CustomerProfile>(e =>
        {
            e.ToTable("cd_customer");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.DisplayName).HasMaxLength(100);
            e.Property(x => x.CreatedAt).HasColumnType("datetime");
            e.Property(x => x.LastSeenAt).HasColumnType("datetime");
        });

        modelBuilder.Entity<BaseProduct>(e =>
        {
            e.ToTable("cd_baseproduct");
            e.HasKey(x => x.Idsanpham);
            e.Property(x => x.Idsanpham).ValueGeneratedNever();
            e.Property(x => x.CreatedAt).HasColumnType("datetime");

            e.HasOne(x => x.Sanpham).WithOne()
                .HasForeignKey<BaseProduct>(x => x.Idsanpham)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<OptionGroup>(e =>
        {
            e.ToTable("cd_optiongroup");
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).HasMaxLength(100).IsRequired();
            e.Property(x => x.Description).HasMaxLength(255);
            e.Ignore(x => x.EffectiveMin);
            e.HasIndex(x => x.Name).IsUnique();
        });

        modelBuilder.Entity<BaseProductOptionGroup>(e =>
        {
            e.ToTable("cd_baseproduct_optiongroup");
            e.HasKey(x => new { x.Idsanpham, x.OptionGroupId });

            e.HasOne(x => x.BaseProduct).WithMany(p => p.OptionGroupLinks)
                .HasForeignKey(x => x.Idsanpham)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.OptionGroup).WithMany(g => g.BaseProductLinks)
                .HasForeignKey(x => x.OptionGroupId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<DrinkOption>(e =>
        {
            e.ToTable("cd_option");
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).HasMaxLength(100).IsRequired();
            e.Property(x => x.ExtraPrice).HasColumnType("decimal(12, 0)");
            e.HasIndex(x => new { x.OptionGroupId, x.Name }).IsUnique();

            e.HasOne(x => x.OptionGroup).WithMany(g => g.Options)
                .HasForeignKey(x => x.OptionGroupId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<OptionIngredient>(e =>
        {
            e.ToTable("cd_option_ingredient");
            e.HasKey(x => new { x.OptionId, x.Idnguyenlieu });
            e.Property(x => x.ConsumptionQuantity).HasColumnType("decimal(12, 2)");

            e.HasOne(x => x.Option).WithMany(o => o.Ingredients)
                .HasForeignKey(x => x.OptionId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Nguyenlieu).WithMany()
                .HasForeignKey(x => x.Idnguyenlieu)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<CustomRecipe>(e =>
        {
            e.ToTable("cd_customrecipe");
            e.HasKey(x => x.Id);
            e.Property(x => x.ConfigHash).HasMaxLength(64).IsUnicode(false).IsRequired();
            e.Property(x => x.CreatedAt).HasColumnType("datetime");
            e.Property(x => x.LastOrderedAt).HasColumnType("datetime");
            e.HasIndex(x => x.ConfigHash).IsUnique();
            e.HasIndex(x => x.OrderCount);

            e.HasOne(x => x.Sanpham).WithMany()
                .HasForeignKey(x => x.Idsanpham)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<CustomRecipeDetail>(e =>
        {
            e.ToTable("cd_customrecipedetail");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.CustomRecipeId, x.OptionId }).IsUnique();

            e.HasOne(x => x.CustomRecipe).WithMany(r => r.Details)
                .HasForeignKey(x => x.CustomRecipeId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Option).WithMany()
                .HasForeignKey(x => x.OptionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<UserSavedRecipe>(e =>
        {
            e.ToTable("cd_usersavedrecipe");
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).HasMaxLength(100).IsRequired();
            e.Property(x => x.Note).HasMaxLength(500);
            e.Property(x => x.CreatedAt).HasColumnType("datetime");
            e.Property(x => x.UpdatedAt).HasColumnType("datetime");
            e.HasIndex(x => new { x.CustomerId, x.CustomRecipeId }).IsUnique();
            e.HasIndex(x => new { x.CustomerId, x.Name }).IsUnique();
            e.HasIndex(x => new { x.IsPublic, x.CustomRecipeId });

            e.HasOne(x => x.Customer).WithMany()
                .HasForeignKey(x => x.CustomerId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.CustomRecipe).WithMany(r => r.SavedBy)
                .HasForeignKey(x => x.CustomRecipeId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        return modelBuilder;
    }
}
