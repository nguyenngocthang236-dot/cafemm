using QuanCafe.CustomDrink.Exceptions;
using QuanCafe.CustomDrink.Infrastructure;
using QuanCafe.CustomDrink.Repositories;
using QuanCafe.CustomDrink.Services;

// Cố ý đặt trong namespace Microsoft.Extensions.DependencyInjection để Program.cs chỉ cần thêm đúng MỘT dòng,
// không cần thêm "using".
namespace Microsoft.Extensions.DependencyInjection;

public static class CustomDrinkServiceCollectionExtensions
{
    /// <summary>Đăng ký toàn bộ dịch vụ của tính năng "Tự sáng tạo món uống". Gọi một lần trong Program.cs.</summary>
    public static IServiceCollection AddCustomDrinkFeature(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<CustomDrinkOptions>(configuration.GetSection("CustomDrink"));
        services.AddHttpContextAccessor();

        // Repositories (dùng chung AppDbContext scoped của code gốc)
        services.AddScoped<IOptionCatalogRepository, OptionCatalogRepository>();
        services.AddScoped<ICustomRecipeRepository, CustomRecipeRepository>();
        services.AddScoped<ISavedRecipeRepository, SavedRecipeRepository>();
        services.AddScoped<ICustomOrderRepository, CustomOrderRepository>();

        // Services
        services.AddScoped<IDrinkBuilderService, DrinkBuilderService>();
        services.AddScoped<IMenuOptionAdminService, MenuOptionAdminService>();
        services.AddScoped<ISavedRecipeService, SavedRecipeService>();
        services.AddScoped<ICommunityRecipeService, CommunityRecipeService>();
        services.AddScoped<ICustomOrderService, CustomOrderService>();

        // Hạ tầng
        services.AddScoped<ICustomDrinkSession, CustomDrinkSession>();
        services.AddScoped<ICurrentCustomerAccessor, CookieCustomerAccessor>();
        services.AddScoped<CustomDrinkExceptionFilter>();
        services.AddScoped<AdminApiKeyFilter>();

        return services;
    }
}
