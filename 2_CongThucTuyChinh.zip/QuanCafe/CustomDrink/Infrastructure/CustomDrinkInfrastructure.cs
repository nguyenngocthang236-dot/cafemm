using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using QuanCafe.CustomDrink.Dtos;
using QuanCafe.Helpers;
using QuanCafe.Models;

namespace QuanCafe.CustomDrink.Infrastructure;

/// <summary>Cấu hình đọc từ appsettings.json, mục "CustomDrink" (đều tuỳ chọn).</summary>
public sealed class CustomDrinkOptions
{
    /// <summary>true = từ chối đơn khi không đủ nguyên liệu; false (mặc định) = vẫn bán, kho trừ tối đa về 0.</summary>
    public bool EnforceStock { get; set; }

    /// <summary>Khoá cho các API quản trị (header X-Admin-Key). Để trống thì chỉ cho gọi khi chạy Development.</summary>
    public string? AdminApiKey { get; set; }

    public int MaxSavedRecipesPerCustomer { get; set; } = 50;
}

/// <summary>Truy cập Session dùng chung: giỏ hàng món tự chọn và phiên bàn (do BanController ghi).</summary>
public interface ICustomDrinkSession
{
    List<CustomCartItem> LoadCart();
    void SaveCart(List<CustomCartItem> cart);
    void ClearCart();
    int? IdPhien { get; }
    int? IdBan { get; }
}

public sealed class CustomDrinkSession : ICustomDrinkSession
{
    /// <summary>Khoá Session riêng, không dùng chung với giỏ hàng cũ ("GioHang") nên không ghi đè lẫn nhau.</summary>
    public const string CartKey = "GioHangTuyChinh";

    private readonly IHttpContextAccessor _http;

    public CustomDrinkSession(IHttpContextAccessor http) => _http = http;

    private ISession Session =>
        _http.HttpContext?.Session ?? throw new InvalidOperationException("Session chưa sẵn sàng.");

    public List<CustomCartItem> LoadCart() => Session.GetObject<List<CustomCartItem>>(CartKey) ?? new List<CustomCartItem>();
    public void SaveCart(List<CustomCartItem> cart) => Session.SetObject(CartKey, cart);
    public void ClearCart() => Session.Remove(CartKey);
    public int? IdPhien => Session.GetInt32(SessionKeys.IdPhien);
    public int? IdBan => Session.GetInt32(SessionKeys.IdBan);
}

/// <summary>
/// Xác định "người dùng" của công thức đã lưu. Hiện tại hệ thống chưa có đăng nhập nên dùng cookie ẩn danh;
/// khi có tài khoản thật chỉ cần viết lại lớp này (trả về Id của tài khoản).
/// </summary>
public interface ICurrentCustomerAccessor
{
    /// <summary>Id khách nếu trình duyệt đã có cookie hợp lệ (không ghi database).</summary>
    Guid? TryGetCustomerId();

    /// <summary>Lấy Id khách, tạo mới (và đặt cookie) nếu chưa có.</summary>
    Task<Guid> GetOrCreateCustomerIdAsync(CancellationToken ct);
}

public sealed class CookieCustomerAccessor : ICurrentCustomerAccessor
{
    public const string CookieName = "qc_customer";

    private readonly IHttpContextAccessor _http;
    private readonly AppDbContext _db;

    public CookieCustomerAccessor(IHttpContextAccessor http, AppDbContext db)
    {
        _http = http;
        _db = db;
    }

    public Guid? TryGetCustomerId()
    {
        var raw = _http.HttpContext?.Request.Cookies[CookieName];
        return Guid.TryParse(raw, out var id) && id != Guid.Empty ? id : null;
    }

    public async Task<Guid> GetOrCreateCustomerIdAsync(CancellationToken ct)
    {
        var ctx = _http.HttpContext ?? throw new InvalidOperationException("Không có HttpContext.");
        var id = TryGetCustomerId() ?? Guid.NewGuid();

        var exists = await _db.CustomerProfiles.AnyAsync(c => c.Id == id, ct);
        if (!exists)
        {
            _db.CustomerProfiles.Add(new Entities.CustomerProfile { Id = id });
            try
            {
                await _db.SaveChangesAsync(ct);
            }
            catch (DbUpdateException)
            {
                // Hai request đầu tiên cùng lúc cùng tạo một Id: bản ghi đã có thì bỏ qua.
                _db.ChangeTracker.Clear();
                if (!await _db.CustomerProfiles.AnyAsync(c => c.Id == id, ct)) throw;
            }
        }

        if (TryGetCustomerId() != id)
        {
            ctx.Response.Cookies.Append(CookieName, id.ToString(), new CookieOptions
            {
                HttpOnly = true,
                IsEssential = true,
                SameSite = SameSiteMode.Lax,
                Secure = ctx.Request.IsHttps,
                Expires = DateTimeOffset.UtcNow.AddYears(2)
            });
        }

        return id;
    }
}

/// <summary>
/// Bảo vệ các API quản trị bằng header X-Admin-Key (khớp CustomDrink:AdminApiKey).
/// Code gốc chưa có đăng nhập nên đây là lớp bảo vệ tối thiểu; có thể thay bằng [Authorize] sau này.
/// </summary>
public sealed class AdminApiKeyFilter : IActionFilter
{
    public const string HeaderName = "X-Admin-Key";

    private readonly CustomDrinkOptions _options;
    private readonly IHostEnvironment _env;

    public AdminApiKeyFilter(IOptions<CustomDrinkOptions> options, IHostEnvironment env)
    {
        _options = options.Value;
        _env = env;
    }

    public void OnActionExecuting(ActionExecutingContext context)
    {
        if (string.IsNullOrWhiteSpace(_options.AdminApiKey))
        {
            if (_env.IsDevelopment()) return;
            context.Result = Deny(StatusCodes.Status403Forbidden, "Chưa cấu hình CustomDrink:AdminApiKey nên API quản trị bị khoá.");
            return;
        }

        var supplied = context.HttpContext.Request.Headers[HeaderName].ToString();
        if (string.IsNullOrEmpty(supplied))
        {
            context.Result = Deny(StatusCodes.Status401Unauthorized, "Thiếu header X-Admin-Key.");
            return;
        }

        var a = Encoding.UTF8.GetBytes(supplied);
        var b = Encoding.UTF8.GetBytes(_options.AdminApiKey);
        if (!CryptographicOperations.FixedTimeEquals(a, b))
            context.Result = Deny(StatusCodes.Status403Forbidden, "Khoá quản trị không đúng.");
    }

    public void OnActionExecuted(ActionExecutedContext context) { }

    private static ObjectResult Deny(int status, string message) =>
        new(new ProblemDetails { Status = status, Title = message }) { StatusCode = status };
}
