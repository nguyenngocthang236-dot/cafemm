namespace QuanCafe.CustomDrink.Dtos;

// ===================== Request DTOs =====================

/// <summary>Một lựa chọn khách chọn kèm số lượng.</summary>
public sealed record OptionSelectionDto(int OptionId, int Quantity = 1);

/// <summary>Cấu hình món custom gửi từ client: món nền + danh sách lựa chọn kèm số lượng.</summary>
public sealed record CustomDrinkRequest(int BaseProductId, IReadOnlyList<OptionSelectionDto>? SelectedOptions);

public sealed record AddToCartRequest(int BaseProductId, IReadOnlyList<OptionSelectionDto>? SelectedOptions, int Quantity = 1);
public sealed record AddSavedToCartRequest(int Quantity = 1);
public sealed record CheckoutRequest(string? Note);

public sealed record SaveRecipeRequest(
    string Name, string? Note, bool IsPublic, int BaseProductId, IReadOnlyList<OptionSelectionDto>? SelectedOptions);

/// <summary>Chỉ trường nào khác null mới được cập nhật.</summary>
public sealed record UpdateRecipeRequest(string? Name, string? Note, bool? IsPublic);

// Admin
public sealed record UpsertOptionGroupRequest(
    string Name, string? Description, bool IsRequired, int MinSelect, int MaxSelect, int SortOrder = 0, bool IsActive = true);

public sealed record UpsertOptionRequest(
    string Name, decimal ExtraPrice, int MaxQuantity = 1, bool IsDefault = false, bool IsActive = true, int SortOrder = 0);

public sealed record IngredientMappingItem(int IngredientId, decimal ConsumptionQuantity);
public sealed record SetIngredientMappingRequest(IReadOnlyList<IngredientMappingItem>? Items);
public sealed record ConfigureBaseProductRequest(bool IsCustomizable, IReadOnlyList<int>? OptionGroupIds);

// ===================== Response DTOs =====================

// Admin
public sealed record OptionIngredientDto(int IngredientId, string? IngredientName, string? Unit, decimal ConsumptionQuantity);

public sealed record OptionDto(
    int Id, int OptionGroupId, string Name, decimal ExtraPrice, int MaxQuantity, bool IsDefault, bool IsActive, int SortOrder,
    IReadOnlyList<OptionIngredientDto> Ingredients);

public sealed record OptionGroupDto(
    int Id, string Name, string? Description, bool IsRequired, int MinSelect, int MaxSelect, int SortOrder, bool IsActive,
    IReadOnlyList<OptionDto> Options);

public sealed record BaseProductDto(int ProductId, string Name, decimal Price, bool IsCustomizable, IReadOnlyList<int> OptionGroupIds);
public sealed record DeleteResultDto(bool Deleted, bool Deactivated, string Message);

// Trình tạo món (khách hàng)
public sealed record BuilderOptionDto(int Id, string Name, decimal ExtraPrice, int MaxQuantity, bool IsDefault);

public sealed record BuilderGroupDto(
    int Id, string Name, string? Description, bool IsRequired, int MinSelect, int MaxSelect, IReadOnlyList<BuilderOptionDto> Options);

public sealed record BuilderMenuDto(
    int BaseProductId, string Name, decimal BasePrice, string? Image, IReadOnlyList<BuilderGroupDto> Groups);

public sealed record QuoteOptionLine(int OptionId, string GroupName, string OptionName, int Quantity, decimal ExtraPrice, decimal LineTotal);

/// <summary>Lượng nguyên liệu tiêu hao cho MỘT ly.</summary>
public sealed record IngredientConsumption(int IngredientId, string Name, string Unit, decimal Quantity);

/// <summary>Kết quả tính giá + định lượng cho một ly custom (giá lấy từ database, không tin client).</summary>
public sealed record DrinkQuote(
    int BaseProductId,
    string BaseProductName,
    decimal BasePrice,
    decimal ExtraTotal,
    decimal UnitPrice,
    IReadOnlyList<QuoteOptionLine> Options,
    IReadOnlyList<IngredientConsumption> Ingredients,
    string Description,
    string ConfigHash);

// Giỏ hàng + đặt hàng
public sealed record CartLineDto(int CustomRecipeId, int? SavedRecipeId, int Quantity, DrinkQuote? Quote, decimal LineTotal, string? Problem);
public sealed record CartDto(IReadOnlyList<CartLineDto> Lines, int TotalQuantity, decimal TotalPrice);
public sealed record CheckoutResultDto(int OrderId, string OrderCode, decimal TotalPrice, IReadOnlyList<IngredientConsumption> StockDeducted);

// Công thức đã lưu / cộng đồng
public sealed record RecipeOptionDto(int OptionId, string GroupName, string OptionName, int Quantity);

public sealed record SavedRecipeDto(
    int Id, string Name, string? Note, bool IsPublic, int OrderCount, int CustomRecipeId,
    int BaseProductId, string BaseProductName, IReadOnlyList<RecipeOptionDto> Options,
    decimal CurrentUnitPrice, bool IsAvailable, DateTime CreatedAt, DateTime UpdatedAt);

public sealed record CommunityRecipeDto(
    int CustomRecipeId, string Name, int BaseProductId, string BaseProductName, IReadOnlyList<RecipeOptionDto> Options,
    decimal CurrentUnitPrice, int OrderCount, int SavedByCount);

public sealed record PagedResult<T>(IReadOnlyList<T> Items, int Page, int PageSize, int TotalItems)
{
    public int TotalPages => PageSize <= 0 ? 0 : (int)Math.Ceiling(TotalItems / (double)PageSize);
}

// Giỏ hàng trong Session (chỉ nhớ công thức nào, mấy ly - giá luôn tính lại từ DB)
public sealed class CustomCartItem
{
    public int CustomRecipeId { get; set; }
    public int? SavedRecipeId { get; set; }
    public int Quantity { get; set; }
}
