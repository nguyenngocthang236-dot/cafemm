using Microsoft.EntityFrameworkCore;
using QuanCafe.Helpers;
using QuanCafe.CustomDrink.Dtos;
using QuanCafe.CustomDrink.Entities;
using QuanCafe.CustomDrink.Exceptions;
using QuanCafe.Models;

namespace QuanCafe.CustomDrink.Repositories;

/// <summary>Dữ liệu cần để dựng và kiểm tra một món custom.</summary>
public sealed record BuilderCatalog(
    Sanpham Product, BaseProduct? Base, IReadOnlyList<OptionGroup> Groups, IReadOnlyList<Congthucsanpham> BaseRecipe);

// ============================================================================================
// 1. Danh mục tuỳ chọn (admin + dữ liệu cho trình tạo món)
// ============================================================================================
public interface IOptionCatalogRepository
{
    Task<BuilderCatalog?> GetBuilderCatalogAsync(int productId, CancellationToken ct);

    Task<List<OptionGroup>> ListGroupsAsync(CancellationToken ct);
    Task<OptionGroup?> GetGroupDetailAsync(int id, CancellationToken ct);
    Task<OptionGroup?> FindGroupForUpdateAsync(int id, CancellationToken ct);
    Task<DrinkOption?> GetOptionDetailAsync(int id, CancellationToken ct);
    Task<DrinkOption?> FindOptionForUpdateAsync(int id, CancellationToken ct);
    Task<DrinkOption?> FindOptionWithIngredientsForUpdateAsync(int id, CancellationToken ct);
    Task<bool> GroupNameExistsAsync(string name, int? excludeId, CancellationToken ct);
    Task<bool> OptionNameExistsAsync(int groupId, string name, int? excludeId, CancellationToken ct);
    Task<bool> IsGroupUsedByRecipesAsync(int groupId, CancellationToken ct);
    Task<bool> IsOptionUsedByRecipesAsync(int optionId, CancellationToken ct);
    Task<HashSet<int>> ExistingIngredientIdsAsync(IEnumerable<int> ids, CancellationToken ct);
    Task<HashSet<int>> ExistingGroupIdsAsync(IEnumerable<int> ids, CancellationToken ct);
    Task<bool> ProductExistsAsync(int productId, CancellationToken ct);
    Task<BaseProduct?> FindBaseProductForUpdateAsync(int productId, CancellationToken ct);
    Task<(List<Sanpham> Products, List<BaseProduct> Bases)> ListBaseProductsAsync(CancellationToken ct);

    void Add(OptionGroup group);
    void Add(DrinkOption option);
    void Add(BaseProduct baseProduct);
    void Remove(OptionGroup group);
    void Remove(DrinkOption option);
    Task SaveChangesAsync(CancellationToken ct);
}

public sealed class OptionCatalogRepository : IOptionCatalogRepository
{
    private readonly AppDbContext _db;

    public OptionCatalogRepository(AppDbContext db) => _db = db;

    public async Task<BuilderCatalog?> GetBuilderCatalogAsync(int productId, CancellationToken ct)
    {
        var product = await _db.Sanphams.AsNoTracking()
            .FirstOrDefaultAsync(s => s.Idsanpham == productId && s.Conhang == true && s.Soluongton > 0, ct);
        if (product is null) return null;

        var baseProduct = await _db.BaseProducts.AsNoTracking()
            .FirstOrDefaultAsync(b => b.Idsanpham == productId, ct);

        var groups = await _db.OptionGroups.AsNoTracking()
            .Where(g => g.IsActive && g.BaseProductLinks.Any(l => l.Idsanpham == productId))
            .OrderBy(g => g.SortOrder).ThenBy(g => g.Id)
            .Include(g => g.Options.Where(o => o.IsActive))
                .ThenInclude(o => o.Ingredients)
                    .ThenInclude(i => i.Nguyenlieu)
            .AsSplitQuery()
            .ToListAsync(ct);

        var recipe = await _db.Congthucsanphams.AsNoTracking()
            .Include(c => c.IdnguyenlieuNavigation)
            .Where(c => c.Idsanpham == productId)
            .ToListAsync(ct);

        return new BuilderCatalog(product, baseProduct, groups, recipe);
    }

    public Task<List<OptionGroup>> ListGroupsAsync(CancellationToken ct) =>
        _db.OptionGroups.AsNoTracking()
            .OrderBy(g => g.SortOrder).ThenBy(g => g.Id)
            .Include(g => g.Options).ThenInclude(o => o.Ingredients).ThenInclude(i => i.Nguyenlieu)
            .AsSplitQuery()
            .ToListAsync(ct);

    public Task<OptionGroup?> GetGroupDetailAsync(int id, CancellationToken ct) =>
        _db.OptionGroups.AsNoTracking()
            .Include(g => g.Options).ThenInclude(o => o.Ingredients).ThenInclude(i => i.Nguyenlieu)
            .AsSplitQuery()
            .FirstOrDefaultAsync(g => g.Id == id, ct);

    public Task<OptionGroup?> FindGroupForUpdateAsync(int id, CancellationToken ct) =>
        _db.OptionGroups.FirstOrDefaultAsync(g => g.Id == id, ct);

    public Task<DrinkOption?> GetOptionDetailAsync(int id, CancellationToken ct) =>
        _db.DrinkOptions.AsNoTracking()
            .Include(o => o.Ingredients).ThenInclude(i => i.Nguyenlieu)
            .FirstOrDefaultAsync(o => o.Id == id, ct);

    public Task<DrinkOption?> FindOptionForUpdateAsync(int id, CancellationToken ct) =>
        _db.DrinkOptions.FirstOrDefaultAsync(o => o.Id == id, ct);

    public Task<DrinkOption?> FindOptionWithIngredientsForUpdateAsync(int id, CancellationToken ct) =>
        _db.DrinkOptions.Include(o => o.Ingredients).FirstOrDefaultAsync(o => o.Id == id, ct);

    public Task<bool> GroupNameExistsAsync(string name, int? excludeId, CancellationToken ct) =>
        _db.OptionGroups.AnyAsync(g => g.Name == name && (excludeId == null || g.Id != excludeId), ct);

    public Task<bool> OptionNameExistsAsync(int groupId, string name, int? excludeId, CancellationToken ct) =>
        _db.DrinkOptions.AnyAsync(o => o.OptionGroupId == groupId && o.Name == name && (excludeId == null || o.Id != excludeId), ct);

    public Task<bool> IsGroupUsedByRecipesAsync(int groupId, CancellationToken ct) =>
        _db.CustomRecipeDetails.AnyAsync(d => d.Option.OptionGroupId == groupId, ct);

    public Task<bool> IsOptionUsedByRecipesAsync(int optionId, CancellationToken ct) =>
        _db.CustomRecipeDetails.AnyAsync(d => d.OptionId == optionId, ct);

    public async Task<HashSet<int>> ExistingIngredientIdsAsync(IEnumerable<int> ids, CancellationToken ct)
    {
        var list = ids.Distinct().ToList();
        var found = await _db.Nguyenlieus.AsNoTracking()
            .Where(n => list.Contains(n.Idnguyenlieu)).Select(n => n.Idnguyenlieu).ToListAsync(ct);
        return found.ToHashSet();
    }

    public async Task<HashSet<int>> ExistingGroupIdsAsync(IEnumerable<int> ids, CancellationToken ct)
    {
        var list = ids.Distinct().ToList();
        var found = await _db.OptionGroups.AsNoTracking()
            .Where(g => list.Contains(g.Id)).Select(g => g.Id).ToListAsync(ct);
        return found.ToHashSet();
    }

    public Task<bool> ProductExistsAsync(int productId, CancellationToken ct) =>
        _db.Sanphams.AnyAsync(s => s.Idsanpham == productId, ct);

    public Task<BaseProduct?> FindBaseProductForUpdateAsync(int productId, CancellationToken ct) =>
        _db.BaseProducts.Include(b => b.OptionGroupLinks).FirstOrDefaultAsync(b => b.Idsanpham == productId, ct);

    public async Task<(List<Sanpham> Products, List<BaseProduct> Bases)> ListBaseProductsAsync(CancellationToken ct)
    {
        var products = await _db.Sanphams.AsNoTracking().OrderBy(s => s.Idsanpham).ToListAsync(ct);
        var bases = await _db.BaseProducts.AsNoTracking().Include(b => b.OptionGroupLinks).ToListAsync(ct);
        return (products, bases);
    }

    public void Add(OptionGroup group) => _db.OptionGroups.Add(group);
    public void Add(DrinkOption option) => _db.DrinkOptions.Add(option);
    public void Add(BaseProduct baseProduct) => _db.BaseProducts.Add(baseProduct);
    public void Remove(OptionGroup group) => _db.OptionGroups.Remove(group);
    public void Remove(DrinkOption option) => _db.DrinkOptions.Remove(option);
    public Task SaveChangesAsync(CancellationToken ct) => _db.SaveChangesAsync(ct);
}

// ============================================================================================
// 2. Cấu hình món (CustomRecipe) + thống kê cộng đồng
// ============================================================================================
public sealed record CommunityRow(CustomRecipe Recipe, string DisplayName, int SavedByCount);

public interface ICustomRecipeRepository
{
    /// <summary>Lấy công thức theo ConfigHash, chưa có thì tạo mới (an toàn khi hai request tạo cùng lúc).</summary>
    Task<CustomRecipe> GetOrCreateAsync(DrinkQuote quote, CancellationToken ct);

    /// <summary>Đọc công thức kèm chi tiết, món nền, lựa chọn, nhóm (không tracking).</summary>
    Task<CustomRecipe?> GetWithDetailsAsync(int id, CancellationToken ct);

    Task<List<CommunityRow>> GetTopCommunityAsync(int take, int? baseProductId, CancellationToken ct);
}

public sealed class CustomRecipeRepository : ICustomRecipeRepository
{
    private readonly AppDbContext _db;

    public CustomRecipeRepository(AppDbContext db) => _db = db;

    public async Task<CustomRecipe> GetOrCreateAsync(DrinkQuote quote, CancellationToken ct)
    {
        var existing = await _db.CustomRecipes.FirstOrDefaultAsync(r => r.ConfigHash == quote.ConfigHash, ct);
        if (existing is not null) return existing;

        var recipe = new CustomRecipe
        {
            Idsanpham = quote.BaseProductId,
            ConfigHash = quote.ConfigHash,
            CreatedAt = DateTime.Now
        };
        foreach (var line in quote.Options)
            recipe.Details.Add(new CustomRecipeDetail { OptionId = line.OptionId, Quantity = line.Quantity });

        _db.CustomRecipes.Add(recipe);
        try
        {
            await _db.SaveChangesAsync(ct);
            return recipe;
        }
        catch (DbUpdateException)
        {
            // Request khác vừa tạo cùng cấu hình (vi phạm unique ConfigHash): bỏ bản của mình, lấy bản đã có.
            // Hàm này luôn được gọi trước khi service thêm entity khác nên chỉ có entity của chính nó ở trạng thái Added.
            foreach (var entry in _db.ChangeTracker.Entries().Where(e => e.State == EntityState.Added).ToList())
                entry.State = EntityState.Detached;

            var raced = await _db.CustomRecipes.FirstOrDefaultAsync(r => r.ConfigHash == quote.ConfigHash, ct);
            if (raced is not null) return raced;
            throw;
        }
    }

    public Task<CustomRecipe?> GetWithDetailsAsync(int id, CancellationToken ct) =>
        _db.CustomRecipes.AsNoTracking()
            .Include(r => r.Sanpham)
            .Include(r => r.Details).ThenInclude(d => d.Option).ThenInclude(o => o.OptionGroup)
            .AsSplitQuery()
            .FirstOrDefaultAsync(r => r.Id == id, ct);

    public async Task<List<CommunityRow>> GetTopCommunityAsync(int take, int? baseProductId, CancellationToken ct)
    {
        var query = _db.CustomRecipes.AsNoTracking()
            .Where(r => r.OrderCount > 0 && r.SavedBy.Any(s => s.IsPublic));
        if (baseProductId.HasValue)
            query = query.Where(r => r.Idsanpham == baseProductId.Value);

        var top = await query
            .OrderByDescending(r => r.OrderCount).ThenBy(r => r.Id)
            .Take(take)
            .Include(r => r.Sanpham)
            .Include(r => r.Details).ThenInclude(d => d.Option).ThenInclude(o => o.OptionGroup)
            .AsSplitQuery()
            .ToListAsync(ct);
        if (top.Count == 0) return new List<CommunityRow>();

        var ids = top.Select(r => r.Id).ToList();
        var names = await _db.UserSavedRecipes.AsNoTracking()
            .Where(s => s.IsPublic && ids.Contains(s.CustomRecipeId))
            .Select(s => new { s.CustomRecipeId, s.Name, s.OrderCount, s.Id })
            .ToListAsync(ct);

        return top.Select(r =>
        {
            var mine = names.Where(n => n.CustomRecipeId == r.Id).ToList();
            // Tên hiển thị = tên của người đặt nhiều nhất công thức này (hoà thì lấy tên lưu sớm nhất).
            var display = mine.Count == 0
                ? "Công thức cộng đồng"
                : mine.OrderByDescending(n => n.OrderCount).ThenBy(n => n.Id).First().Name;
            return new CommunityRow(r, display, mine.Count);
        }).ToList();
    }
}

// ============================================================================================
// 3. Công thức đã lưu của khách
// ============================================================================================
public interface ISavedRecipeRepository
{
    Task<(List<UserSavedRecipe> Items, int Total)> SearchAsync(Guid customerId, string? search, int page, int pageSize, CancellationToken ct);
    Task<UserSavedRecipe?> GetAsync(Guid customerId, int id, bool tracking, CancellationToken ct);
    Task<int> CountAsync(Guid customerId, CancellationToken ct);
    Task<bool> ExistsForRecipeAsync(Guid customerId, int customRecipeId, CancellationToken ct);
    Task<bool> NameExistsAsync(Guid customerId, string name, int? excludeId, CancellationToken ct);
    void Add(UserSavedRecipe saved);
    void Remove(UserSavedRecipe saved);
    Task SaveChangesAsync(CancellationToken ct);
}

public sealed class SavedRecipeRepository : ISavedRecipeRepository
{
    private readonly AppDbContext _db;

    public SavedRecipeRepository(AppDbContext db) => _db = db;

    private IQueryable<UserSavedRecipe> WithIncludes(IQueryable<UserSavedRecipe> q) =>
        q.Include(s => s.CustomRecipe).ThenInclude(r => r.Sanpham)
         .Include(s => s.CustomRecipe).ThenInclude(r => r.Details).ThenInclude(d => d.Option).ThenInclude(o => o.OptionGroup)
         .AsSplitQuery();

    public async Task<(List<UserSavedRecipe> Items, int Total)> SearchAsync(
        Guid customerId, string? search, int page, int pageSize, CancellationToken ct)
    {
        var filtered = _db.UserSavedRecipes.AsNoTracking().Where(s => s.CustomerId == customerId);

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            filtered = filtered.Where(s =>
                s.Name.Contains(term)
                || (s.Note != null && s.Note.Contains(term))
                || s.CustomRecipe.Sanpham.Tensanpham.Contains(term)
                || s.CustomRecipe.Details.Any(d => d.Option.Name.Contains(term)));
        }

        var total = await filtered.CountAsync(ct);
        var items = await WithIncludes(
                filtered.OrderByDescending(s => s.CreatedAt).ThenByDescending(s => s.Id)
                        .Skip((page - 1) * pageSize).Take(pageSize))
            .ToListAsync(ct);

        return (items, total);
    }

    public Task<UserSavedRecipe?> GetAsync(Guid customerId, int id, bool tracking, CancellationToken ct)
    {
        IQueryable<UserSavedRecipe> q = _db.UserSavedRecipes;
        if (!tracking) q = q.AsNoTracking();
        return WithIncludes(q).FirstOrDefaultAsync(s => s.Id == id && s.CustomerId == customerId, ct);
    }

    public Task<int> CountAsync(Guid customerId, CancellationToken ct) =>
        _db.UserSavedRecipes.CountAsync(s => s.CustomerId == customerId, ct);

    public Task<bool> ExistsForRecipeAsync(Guid customerId, int customRecipeId, CancellationToken ct) =>
        _db.UserSavedRecipes.AnyAsync(s => s.CustomerId == customerId && s.CustomRecipeId == customRecipeId, ct);

    public Task<bool> NameExistsAsync(Guid customerId, string name, int? excludeId, CancellationToken ct) =>
        _db.UserSavedRecipes.AnyAsync(s => s.CustomerId == customerId && s.Name == name && (excludeId == null || s.Id != excludeId), ct);

    public void Add(UserSavedRecipe saved) => _db.UserSavedRecipes.Add(saved);
    public void Remove(UserSavedRecipe saved) => _db.UserSavedRecipes.Remove(saved);
    public Task SaveChangesAsync(CancellationToken ct) => _db.SaveChangesAsync(ct);
}

// ============================================================================================
// 4. Tạo đơn hàng có trừ kho (transaction)
// ============================================================================================
public sealed record PlaceOrderLine(
    int CustomRecipeId, int? SavedRecipeId, int BaseProductId, int Quantity, decimal UnitPrice,
    string Description, IReadOnlyList<IngredientConsumption> IngredientsPerUnit);

public sealed record PlacedOrder(int OrderId, string OrderCode, decimal Total, IReadOnlyList<IngredientConsumption> StockDeducted);

public interface ICustomOrderRepository
{
    Task<bool> IsTableSessionOpenAsync(int idPhien, int idBan, CancellationToken ct);

    /// <summary>
    /// Trong MỘT transaction: tạo Donhang + Chitietdon, trừ kho nguyên liệu (ghi Lichsukho),
    /// cộng số lượt đặt cho CustomRecipe / UserSavedRecipe. Lỗi ở bất kỳ bước nào thì rollback toàn bộ.
    /// </summary>
    Task<PlacedOrder> PlaceAsync(
        int idPhien, int idBan, string? note, Guid? customerId,
        IReadOnlyList<PlaceOrderLine> lines, bool enforceStock, CancellationToken ct);
}

public sealed class CustomOrderRepository : ICustomOrderRepository
{
    private readonly AppDbContext _db;

    public CustomOrderRepository(AppDbContext db) => _db = db;

    public Task<bool> IsTableSessionOpenAsync(int idPhien, int idBan, CancellationToken ct) =>
        _db.Phiensudungbans.AnyAsync(p => p.Idphien == idPhien && p.Idban == idBan && p.Trangthai == "dangmo", ct);

    public async Task<PlacedOrder> PlaceAsync(
        int idPhien, int idBan, string? note, Guid? customerId,
        IReadOnlyList<PlaceOrderLine> lines, bool enforceStock, CancellationToken ct)
    {
        var strategy = _db.Database.CreateExecutionStrategy();
        return await strategy.ExecuteAsync(async () =>
        {
            await using var tx = await _db.Database.BeginTransactionAsync(ct);

            // ---- 1. Đơn hàng + chi tiết (cùng khuôn với GioHangController.DatHang của code gốc) ----
            var don = new Donhang
            {
                Idphien = idPhien,
                Idban = idBan,
                Trangthai = "choxacnhan",
                Trangthaithanhtoan = "chuathanhtoan",
                Thoigiandat = DateTime.Now,
                Ghichu = note,
                Tongtien = lines.Sum(l => l.UnitPrice * l.Quantity)
            };
            foreach (var l in lines)
            {
                don.Chitietdons.Add(new Chitietdon
                {
                    Idsanpham = l.BaseProductId,
                    Soluong = l.Quantity,
                    Dongia = l.UnitPrice,
                    Trangthai = "cholam",
                    Ghichu = Truncate(l.Description, 255) // cột ghichu dài 255
                });
            }
            _db.Donhangs.Add(don);

            for (var attempt = 1; ; attempt++)
            {
                don.Madonhang = await NextOrderCodeAsync(ct);
                try
                {
                    await _db.SaveChangesAsync(ct);
                    break;
                }
                catch (DbUpdateException) when (attempt < 3)
                {
                    // Trùng mã đơn do hai khách đặt cùng lúc -> sinh mã mới rồi lưu lại.
                }
            }

            // ---- 1b. Trừ tồn kho của MÓN NỀN (sanpham.soluongton), giống GioHangController.DatHang ----
            // Dùng chung KhoHang.ThayDoiAsync để cột conhang cũng được cập nhật khi món hết hàng.
            foreach (var g in lines.GroupBy(l => l.BaseProductId))
            {
                var soLy = g.Sum(l => l.Quantity);
                if (!await KhoHang.ThayDoiAsync(_db, g.Key, -soLy, ct))
                    throw new BusinessRuleException("INSUFFICIENT_STOCK",
                        "Món nền của đồ uống này không còn đủ số lượng trong kho. Bạn giảm số ly hoặc chọn món khác nhé.");
            }

            // ---- 2. Trừ kho: gộp nhu cầu của mọi dòng theo nguyên liệu ----
            var needs = lines
                .SelectMany(l => l.IngredientsPerUnit.Select(i => new { i.IngredientId, i.Name, i.Unit, Qty = i.Quantity * l.Quantity }))
                .GroupBy(x => x.IngredientId)
                .Select(g => new IngredientConsumption(g.Key, g.First().Name, g.First().Unit, g.Sum(x => x.Qty)))
                .Where(n => n.Quantity > 0)
                .ToList();

            foreach (var need in needs)
            {
                var id = need.IngredientId;
                var qty = need.Quantity;

                int affected;
                if (enforceStock)
                {
                    // Điều kiện tồn >= qty nằm ngay trong câu UPDATE nên hai đơn cùng lúc không thể trừ âm kho.
                    affected = await _db.Nguyenlieus
                        .Where(n => n.Idnguyenlieu == id && n.Soluongtonkho >= qty)
                        .ExecuteUpdateAsync(s => s.SetProperty(n => n.Soluongtonkho, n => n.Soluongtonkho - qty), ct);

                    if (affected == 0)
                        throw new BusinessRuleException("INSUFFICIENT_STOCK", $"Không đủ nguyên liệu \"{need.Name}\" để pha món này.");
                }
                else
                {
                    // Không chặn đơn: trừ tối đa về 0 (lịch sử kho vẫn ghi đúng lượng tiêu hao thực tế).
                    await _db.Nguyenlieus
                        .Where(n => n.Idnguyenlieu == id)
                        .ExecuteUpdateAsync(s => s.SetProperty(
                            n => n.Soluongtonkho,
                            n => (decimal?)((n.Soluongtonkho ?? 0m) >= qty ? (n.Soluongtonkho ?? 0m) - qty : 0m)), ct);
                }

                _db.Lichsukhos.Add(new Lichsukho
                {
                    Idnguyenlieu = id,
                    Loai = "xuat",
                    Soluong = qty,
                    IdonhangLienQuan = don.Idonhang,
                    Thoigiantao = DateTime.Now
                });
            }
            await _db.SaveChangesAsync(ct);

            // ---- 3. Thống kê lượt đặt ----
            DateTime? now = DateTime.Now;
            foreach (var g in lines.GroupBy(l => l.CustomRecipeId))
            {
                var recipeId = g.Key;
                var qty = g.Sum(l => l.Quantity);
                await _db.CustomRecipes.Where(r => r.Id == recipeId)
                    .ExecuteUpdateAsync(s => s
                        .SetProperty(r => r.OrderCount, r => r.OrderCount + qty)
                        .SetProperty(r => r.LastOrderedAt, now), ct);
            }

            if (customerId.HasValue)
            {
                var owner = customerId.Value;
                foreach (var g in lines.Where(l => l.SavedRecipeId.HasValue).GroupBy(l => l.SavedRecipeId!.Value))
                {
                    var savedId = g.Key;
                    var qty = g.Sum(l => l.Quantity);
                    // Lọc thêm theo CustomerId để không ai cộng lượt đặt cho công thức của người khác.
                    await _db.UserSavedRecipes.Where(s => s.Id == savedId && s.CustomerId == owner)
                        .ExecuteUpdateAsync(s => s.SetProperty(x => x.OrderCount, x => x.OrderCount + qty), ct);
                }
            }

            await tx.CommitAsync(ct);
            return new PlacedOrder(don.Idonhang, don.Madonhang, don.Tongtien ?? 0m, needs);
        });
    }

    /// <summary>Mã đơn dạng 261028-007 = ngày + số thứ tự trong ngày (giống GioHangController).</summary>
    private async Task<string> NextOrderCodeAsync(CancellationToken ct)
    {
        var today = DateTime.Today;
        var tomorrow = today.AddDays(1);
        var count = await _db.Donhangs.CountAsync(d => d.Thoigiandat >= today && d.Thoigiandat < tomorrow, ct);
        return $"{today:yyMMdd}-{count + 1:000}";
    }

    private static string Truncate(string text, int max) => text.Length <= max ? text : text[..(max - 1)] + "…";
}
