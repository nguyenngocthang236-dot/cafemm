# Tính năng "Tự sáng tạo món uống & Lưu công thức"

Toàn bộ code nằm trong thư mục `QuanCafe/CustomDrink/` và **chỉ thêm mới**. Code gốc chỉ bị sửa đúng 1 dòng trong `Program.cs`.

## Vì sao không xung đột với code trong zip

| Điểm dễ xung đột | Cách xử lý |
|---|---|
| Tên lớp / bảng | Entity nằm trong namespace `QuanCafe.CustomDrink.*`, bảng có tiền tố `cd_` (`cd_option`, `cd_customrecipe`, ...). Code gốc dùng tên tiếng Việt (`Sanpham`, `Donhang`) nên không trùng. |
| `AppDbContext` | Mở rộng bằng `partial class` (file `Infrastructure/AppDbContext.CustomDrink.cs`) và hook `OnModelCreatingPartial` mà scaffold đã có sẵn. Không sửa `AppDbContext.cs`. Scaffold lại DB thì file này vẫn còn. |
| Route | Mọi API dưới `api/custom-drinks/...`. Không trùng `api/donhang`, `api/sanpham`, `Menu/Dashboard`, route mặc định. |
| Giỏ hàng | Giỏ riêng trong Session với khoá `GioHangTuyChinh`, không đụng khoá `GioHang` của giỏ cũ. |
| Đơn hàng | Tạo `Donhang` + `Chitietdon` đúng khuôn của `GioHangController.DatHang` (mã đơn `yyMMdd-NNN`, trạng thái `choxacnhan`/`cholam`), nên nhân viên và dashboard thấy đơn như mọi đơn khác. |
| Xử lý lỗi | Dùng exception filter chỉ gắn vào controller mới, không đổi `UseExceptionHandler`. |
| Package | Không thêm NuGet nào. Chạy trên `net10.0` / EF Core 10 của dự án. |

Dự án của bạn là **net10.0 + ASP.NET Core MVC + EF database-first** nên code viết cho đúng stack đó, không dùng .NET 8 như đề bài gốc.

## Cách áp dụng (3 bước)

1. **Sao lưu database `QuanCafe`**, rồi chạy `CustomDrink/Sql/CustomDrink_Schema.sql` trong SSMS. File chỉ tạo bảng `cd_*` mới (chạy lại nhiều lần vẫn an toàn) và nạp dữ liệu mẫu: Size, Mức đường, Mức đá, Loại sữa, Topping.
   - Nếu muốn dùng EF migrations thay cho script: `dotnet ef migrations add CustomDrink` rồi `dotnet ef database update`, và đừng chạy phần tạo bảng của script.
2. `Program.cs` có thêm đúng 1 dòng (đã sửa sẵn trong zip này):
   ```csharp
   builder.Services.AddCustomDrinkFeature(builder.Configuration);
   ```
3. (Tuỳ chọn) thêm vào `appsettings.json`:
   ```json
   "CustomDrink": {
     "AdminApiKey": "doi-thanh-khoa-bi-mat",
     "EnforceStock": false,
     "MaxSavedRecipesPerCustomer": 50
   }
   ```
   - `AdminApiKey`: gửi qua header `X-Admin-Key` để gọi API admin. Để trống thì chỉ gọi được khi chạy `Development`, môi trường khác trả 403.
   - `EnforceStock`: `false` (mặc định) vẫn bán khi thiếu nguyên liệu, kho trừ tối đa về 0. `true` thì từ chối đơn với lỗi 422.

## API

Khách hàng (cần Session; đặt hàng cần đã quét QR tại bàn):

| Method | URL | Mô tả |
|---|---|---|
| GET | `/api/custom-drinks/builder/{baseProductId}` | Các nhóm + lựa chọn của món nền (để dựng giao diện) |
| POST | `/api/custom-drinks/quote` | Kiểm tra + tính giá + định lượng nguyên liệu cho 1 ly (không lưu gì) |
| GET / POST | `/api/custom-drinks/cart` | Xem giỏ / thêm món custom vào giỏ |
| DELETE | `/api/custom-drinks/cart/{customRecipeId}` | Bỏ dòng khỏi giỏ |
| POST | `/api/custom-drinks/cart/checkout` | Đặt hàng: tạo đơn + trừ kho + ghi lượt đặt trong 1 transaction |
| POST | `/api/custom-drinks/recipes` | Lưu công thức kèm tên riêng, ghi chú, `isPublic` |
| GET | `/api/custom-drinks/recipes?search=&page=1&pageSize=10` | Danh sách công thức đã lưu (phân trang, tìm kiếm) |
| GET / PATCH / DELETE | `/api/custom-drinks/recipes/{id}` | Xem / đổi tên, ghi chú, chia sẻ / xoá |
| POST | `/api/custom-drinks/recipes/{id}/add-to-cart` | Re-order: đưa công thức đã lưu vào giỏ |
| GET | `/api/custom-drinks/community/top?take=10&baseProductId=` | Top công thức cộng đồng được đặt nhiều nhất |

Admin (header `X-Admin-Key`), tiền tố `/api/custom-drinks/admin`:

| Method | URL | Mô tả |
|---|---|---|
| GET / POST | `/option-groups` | Liệt kê / tạo nhóm (`isRequired`, `minSelect`, `maxSelect`) |
| GET / PUT / DELETE | `/option-groups/{id}` | Xem / sửa / xoá nhóm (đã dùng trong công thức thì chỉ tắt, không xoá) |
| POST | `/option-groups/{groupId}/options` | Thêm lựa chọn (`extraPrice`, `maxQuantity`) |
| PUT / DELETE | `/options/{id}` | Sửa / xoá lựa chọn |
| PUT | `/options/{id}/ingredients` | Ánh xạ nguyên liệu: `{"items":[{"ingredientId":3,"consumptionQuantity":20}]}` |
| GET | `/base-products` | Các món kèm trạng thái cho tuỳ chỉnh và nhóm đã gán |
| PUT | `/base-products/{productId}` | `{"isCustomizable":true,"optionGroupIds":[1,2,3]}` |

### Ví dụ

```http
POST /api/custom-drinks/quote
{ "baseProductId": 1,
  "selectedOptions": [ {"optionId": 2}, {"optionId": 7}, {"optionId": 10}, {"optionId": 14, "quantity": 2} ] }
```
Trả về `unitPrice` = giá món nền + ∑(số lượng × giá extra), cùng danh sách `ingredients` tiêu hao cho một ly.

Lỗi trả theo ProblemDetails, kèm mảng `errors` (`code`, `field`, `message`):

| Mã | Khi nào |
|---|---|
| 400 | Số lượng ≤ 0, tên rỗng, JSON sai |
| 401 | Đặt hàng khi chưa quét QR / phiên bàn đã đóng |
| 404 | Không có món nền, công thức, nhóm, lựa chọn |
| 409 | Trùng tên công thức / đã lưu cấu hình này / dữ liệu vừa bị đổi |
| 422 | Vi phạm ràng buộc, ví dụ `"Mức đường là bắt buộc."`, `"Số lượng Topping/Extra vượt quá giới hạn (tối đa 3)."`, lựa chọn không thuộc món nền, thiếu nguyên liệu (khi `EnforceStock`) |

## Quy tắc nghiệp vụ

- Một nhóm bắt buộc (`isRequired`) cần ≥ `max(minSelect, 1)` phần. Nhóm không bắt buộc cho phép không chọn gì, nhưng đã chọn thì phải nằm trong `minSelect..maxSelect`.
- `maxSelect` tính trên **tổng số lượng** của mọi lựa chọn trong nhóm. Mỗi lựa chọn còn có `maxQuantity` riêng (ví dụ tối đa 2 phần trân châu).
- Giá luôn tính lại từ database, không tin client. Ràng buộc được kiểm tra lại ở cả bước lưu công thức, thêm vào giỏ và đặt hàng.
- Hai khách chọn giống hệt nhau dùng chung một `CustomRecipe` (nhận diện bằng mã băm SHA-256). Nhờ vậy `OrderCount` cộng dồn và thống kê "Top cộng đồng" chính xác. Khi đặt hàng, `OrderCount` của `CustomRecipe` (toàn hệ thống) và của `UserSavedRecipe` (riêng khách) cùng tăng.
- Top cộng đồng chỉ gồm công thức có ít nhất một người bật `isPublic`.
- Trừ kho: gộp nguyên liệu của món nền (`congthucsanpham`) và của các lựa chọn, trừ bằng câu `UPDATE` nguyên tử, ghi `lichsukho` (`loai = 'xuat'`, gắn `idonhangLienQuan`). Mọi bước nằm chung transaction với việc tạo đơn.

## Lưu ý quan trọng

1. **Chưa chạy `dotnet build`.** Môi trường mình viết code không cài được .NET SDK. Code đã được rà tay và kiểm tra cân bằng cú pháp, nhưng bạn hãy build trong Visual Studio trước. Nếu có lỗi biên dịch, gửi lại mình để sửa.
2. **"Tài khoản người dùng":** hệ thống hiện chưa có đăng nhập, nên khách được nhận diện bằng cookie ẩn danh `qc_customer` (bảng `cd_customer`). Công thức lưu theo trình duyệt. Khi có đăng nhập thật, chỉ cần viết lại `ICurrentCustomerAccessor`.
3. **API admin** chỉ có khoá `X-Admin-Key`, vì code gốc chưa có phân quyền (`QuanLy` cũng đang mở). Nên thay bằng `[Authorize]` khi có đăng nhập.
4. **Nhân viên chưa thấy phần tuỳ chỉnh.** Mô tả (ví dụ `Size: L; Mức đường: 50%; Topping: Trân châu x2`) được lưu trong `chitietdon.ghichu`, nhưng các view cũ chưa hiển thị cột này. Để hiện trong `Views/NhanVien/DanhSachDon.cshtml`, thêm ngay sau dòng `@ct.IdsanphamNavigation.Tensanpham x @ct.Soluong — @ct.Trangthai`:
   ```cshtml
   @if (!string.IsNullOrWhiteSpace(ct.Ghichu)) { <div class="small text-muted">@ct.Ghichu</div> }
   ```
   Làm tương tự ở `Views/DonHang/ThanhCong.cshtml`, `TrangThai.cshtml` và `Views/ThanhToan/ThanhToanCuoi.cshtml` nếu muốn khách cũng thấy. Mình chưa tự sửa các view để không đụng code gốc.
5. **Kho cũ:** code gốc hiện không trừ kho khi bán món thường. Đơn custom thì có trừ. Nếu cột `soluongtonkho` đang để 0, hãy để `EnforceStock = false`, nếu không mọi đơn custom sẽ bị từ chối.
6. Script SQL giả định `lichsukho.loai` nhận giá trị `'xuat'` (chưa kiểm tra được CHECK constraint trên database của bạn). Nếu bạn dùng giá trị khác, đổi hằng `"xuat"` trong `CustomOrderRepository.PlaceAsync`.
7. Món mẫu: script gán nhóm tuỳ chỉnh cho **mọi** món đang bán (`conhang = 1`). Chỉnh lại bằng `PUT /api/custom-drinks/admin/base-products/{id}` cho các món không nên tuỳ chỉnh (bánh ngọt, v.v.).

## Cấu trúc thư mục

```
CustomDrink/
  Entities/        CustomDrinkEntities.cs      (9 entity)
  Dtos/            CustomDrinkDtos.cs          (request/response records)
  Exceptions/      CustomDrinkExceptions.cs    (400/401/404/409/422 + exception filter)
  Infrastructure/  AppDbContext.CustomDrink.cs (partial DbContext + Fluent API)
                   CustomDrinkInfrastructure.cs (options, session, cookie khách, khoá admin)
                   CustomDrinkServiceCollectionExtensions.cs (AddCustomDrinkFeature)
  Repositories/    CustomDrinkRepositories.cs
  Services/        DrinkBuilderService.cs      (kiểm tra ràng buộc + tính giá: hàm thuần, dễ unit test)
                   RecipeServices.cs           (công thức đã lưu, cộng đồng)
                   CustomOrderService.cs       (giỏ + đặt hàng)
                   MenuOptionAdminService.cs   (quản trị danh mục)
  Controllers/     CustomDrinkControllers.cs   (4 controller)
  Sql/             CustomDrink_Schema.sql
```
