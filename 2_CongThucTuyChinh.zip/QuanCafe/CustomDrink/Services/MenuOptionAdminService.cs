using QuanCafe.CustomDrink.Dtos;
using QuanCafe.CustomDrink.Entities;
using QuanCafe.CustomDrink.Exceptions;
using QuanCafe.CustomDrink.Repositories;

namespace QuanCafe.CustomDrink.Services;

public interface IMenuOptionAdminService
{
    Task<IReadOnlyList<OptionGroupDto>> ListGroupsAsync(CancellationToken ct);
    Task<OptionGroupDto> GetGroupAsync(int id, CancellationToken ct);
    Task<OptionGroupDto> CreateGroupAsync(UpsertOptionGroupRequest request, CancellationToken ct);
    Task<OptionGroupDto> UpdateGroupAsync(int id, UpsertOptionGroupRequest request, CancellationToken ct);
    Task<DeleteResultDto> DeleteGroupAsync(int id, CancellationToken ct);

    Task<OptionDto> CreateOptionAsync(int groupId, UpsertOptionRequest request, CancellationToken ct);
    Task<OptionDto> UpdateOptionAsync(int id, UpsertOptionRequest request, CancellationToken ct);
    Task<DeleteResultDto> DeleteOptionAsync(int id, CancellationToken ct);
    Task<OptionDto> SetIngredientMappingAsync(int optionId, SetIngredientMappingRequest request, CancellationToken ct);

    Task<IReadOnlyList<BaseProductDto>> ListBaseProductsAsync(CancellationToken ct);
    Task<BaseProductDto> ConfigureBaseProductAsync(int productId, ConfigureBaseProductRequest request, CancellationToken ct);
}

/// <summary>Quản lý danh mục tuỳ chỉnh (dành cho admin): nhóm, lựa chọn, ánh xạ nguyên liệu, gán nhóm cho món nền.</summary>
public sealed class MenuOptionAdminService : IMenuOptionAdminService
{
    private readonly IOptionCatalogRepository _repo;

    public MenuOptionAdminService(IOptionCatalogRepository repo) => _repo = repo;

    // ---------------- Nhóm tuỳ chỉnh ----------------

    public async Task<IReadOnlyList<OptionGroupDto>> ListGroupsAsync(CancellationToken ct) =>
        (await _repo.ListGroupsAsync(ct)).Select(ToDto).ToList();

    public async Task<OptionGroupDto> GetGroupAsync(int id, CancellationToken ct) =>
        ToDto(await _repo.GetGroupDetailAsync(id, ct) ?? throw GroupNotFound());

    public async Task<OptionGroupDto> CreateGroupAsync(UpsertOptionGroupRequest request, CancellationToken ct)
    {
        var name = ValidateGroup(request);
        if (await _repo.GroupNameExistsAsync(name, null, ct))
            throw new ConflictException("GROUP_NAME_DUPLICATE", $"Đã có nhóm tên \"{name}\".");

        var group = new OptionGroup();
        Apply(group, request, name);
        _repo.Add(group);
        await _repo.SaveChangesAsync(ct);
        return await GetGroupAsync(group.Id, ct);
    }

    public async Task<OptionGroupDto> UpdateGroupAsync(int id, UpsertOptionGroupRequest request, CancellationToken ct)
    {
        var name = ValidateGroup(request);
        var group = await _repo.FindGroupForUpdateAsync(id, ct) ?? throw GroupNotFound();
        if (await _repo.GroupNameExistsAsync(name, id, ct))
            throw new ConflictException("GROUP_NAME_DUPLICATE", $"Đã có nhóm tên \"{name}\".");

        Apply(group, request, name);
        await _repo.SaveChangesAsync(ct);
        return await GetGroupAsync(id, ct);
    }

    /// <summary>Nhóm đã nằm trong công thức/đơn cũ thì chỉ tắt (IsActive = false) để không phá dữ liệu lịch sử; chưa dùng thì xoá hẳn.</summary>
    public async Task<DeleteResultDto> DeleteGroupAsync(int id, CancellationToken ct)
    {
        var group = await _repo.FindGroupForUpdateAsync(id, ct) ?? throw GroupNotFound();

        if (await _repo.IsGroupUsedByRecipesAsync(id, ct))
        {
            group.IsActive = false;
            await _repo.SaveChangesAsync(ct);
            return new DeleteResultDto(false, true, "Nhóm đã được dùng trong công thức nên được tắt thay vì xoá.");
        }

        _repo.Remove(group);
        await _repo.SaveChangesAsync(ct);
        return new DeleteResultDto(true, false, "Đã xoá nhóm.");
    }

    // ---------------- Lựa chọn ----------------

    public async Task<OptionDto> CreateOptionAsync(int groupId, UpsertOptionRequest request, CancellationToken ct)
    {
        var name = ValidateOption(request);
        _ = await _repo.FindGroupForUpdateAsync(groupId, ct) ?? throw GroupNotFound();
        if (await _repo.OptionNameExistsAsync(groupId, name, null, ct))
            throw new ConflictException("OPTION_NAME_DUPLICATE", $"Nhóm này đã có lựa chọn \"{name}\".");

        var option = new DrinkOption { OptionGroupId = groupId };
        Apply(option, request, name);
        _repo.Add(option);
        await _repo.SaveChangesAsync(ct);
        return ToDto(await _repo.GetOptionDetailAsync(option.Id, ct) ?? throw OptionNotFound());
    }

    public async Task<OptionDto> UpdateOptionAsync(int id, UpsertOptionRequest request, CancellationToken ct)
    {
        var name = ValidateOption(request);
        var option = await _repo.FindOptionForUpdateAsync(id, ct) ?? throw OptionNotFound();
        if (await _repo.OptionNameExistsAsync(option.OptionGroupId, name, id, ct))
            throw new ConflictException("OPTION_NAME_DUPLICATE", $"Nhóm này đã có lựa chọn \"{name}\".");

        Apply(option, request, name);
        await _repo.SaveChangesAsync(ct);
        return ToDto(await _repo.GetOptionDetailAsync(id, ct) ?? throw OptionNotFound());
    }

    public async Task<DeleteResultDto> DeleteOptionAsync(int id, CancellationToken ct)
    {
        var option = await _repo.FindOptionForUpdateAsync(id, ct) ?? throw OptionNotFound();

        if (await _repo.IsOptionUsedByRecipesAsync(id, ct))
        {
            option.IsActive = false;
            await _repo.SaveChangesAsync(ct);
            return new DeleteResultDto(false, true, "Lựa chọn đã được dùng trong công thức nên được tắt thay vì xoá.");
        }

        _repo.Remove(option);
        await _repo.SaveChangesAsync(ct);
        return new DeleteResultDto(true, false, "Đã xoá lựa chọn.");
    }

    /// <summary>
    /// Đặt lại toàn bộ ánh xạ lựa chọn -> nguyên liệu (IngredientId + ConsumptionQuantity). Danh sách rỗng = xoá hết ánh xạ.
    /// Cập nhật theo kiểu so khớp (sửa dòng cũ, xoá dòng thừa, thêm dòng mới) để không đụng khoá chính kép.
    /// </summary>
    public async Task<OptionDto> SetIngredientMappingAsync(int optionId, SetIngredientMappingRequest request, CancellationToken ct)
    {
        var items = request.Items ?? Array.Empty<IngredientMappingItem>();

        var errors = new List<ErrorItem>();
        foreach (var item in items)
        {
            if (item.IngredientId <= 0)
                errors.Add(new ErrorItem("INVALID_INGREDIENT", "items", "Mã nguyên liệu không hợp lệ."));
            if (item.ConsumptionQuantity <= 0 || item.ConsumptionQuantity > 1_000_000)
                errors.Add(new ErrorItem("INVALID_CONSUMPTION", $"items[{item.IngredientId}]", "Định lượng tiêu hao phải lớn hơn 0."));
        }
        if (items.GroupBy(i => i.IngredientId).Any(g => g.Count() > 1))
            errors.Add(new ErrorItem("DUPLICATE_INGREDIENT", "items", "Mỗi nguyên liệu chỉ được xuất hiện một lần."));
        if (errors.Count > 0)
            throw new RequestValidationException("INVALID_MAPPING", errors[0].Message, errors);

        var option = await _repo.FindOptionWithIngredientsForUpdateAsync(optionId, ct) ?? throw OptionNotFound();

        var existing = await _repo.ExistingIngredientIdsAsync(items.Select(i => i.IngredientId), ct);
        var missing = items.Where(i => !existing.Contains(i.IngredientId)).Select(i => i.IngredientId).ToList();
        if (missing.Count > 0)
            throw new BusinessRuleException("INGREDIENT_NOT_FOUND",
                $"Không tìm thấy nguyên liệu: {string.Join(", ", missing)}.");

        var wanted = items.ToDictionary(i => i.IngredientId, i => i.ConsumptionQuantity);
        foreach (var current in option.Ingredients.ToList())
        {
            if (wanted.TryGetValue(current.Idnguyenlieu, out var qty))
            {
                current.ConsumptionQuantity = qty;
                wanted.Remove(current.Idnguyenlieu);
            }
            else
            {
                option.Ingredients.Remove(current);
            }
        }
        foreach (var (ingredientId, qty) in wanted)
            option.Ingredients.Add(new OptionIngredient { OptionId = optionId, Idnguyenlieu = ingredientId, ConsumptionQuantity = qty });

        await _repo.SaveChangesAsync(ct);
        return ToDto(await _repo.GetOptionDetailAsync(optionId, ct) ?? throw OptionNotFound());
    }

    // ---------------- Món nền ----------------

    public async Task<IReadOnlyList<BaseProductDto>> ListBaseProductsAsync(CancellationToken ct)
    {
        var (products, bases) = await _repo.ListBaseProductsAsync(ct);
        var byId = bases.ToDictionary(b => b.Idsanpham);

        return products.Select(p =>
        {
            byId.TryGetValue(p.Idsanpham, out var b);
            var groupIds = b is null
                ? new List<int>()
                : b.OptionGroupLinks.OrderBy(l => l.SortOrder).Select(l => l.OptionGroupId).ToList();
            return new BaseProductDto(p.Idsanpham, p.Tensanpham, p.Gia, b?.IsCustomizable ?? false, groupIds);
        }).ToList();
    }

    /// <summary>Bật/tắt khả năng tuỳ chỉnh của một món và gán danh sách nhóm tuỳ chỉnh (thứ tự trong danh sách = thứ tự hiển thị).</summary>
    public async Task<BaseProductDto> ConfigureBaseProductAsync(int productId, ConfigureBaseProductRequest request, CancellationToken ct)
    {
        if (!await _repo.ProductExistsAsync(productId, ct))
            throw new NotFoundException("BASE_PRODUCT_NOT_FOUND", "Không tìm thấy món (sanpham).");

        var groupIds = (request.OptionGroupIds ?? Array.Empty<int>()).Distinct().ToList();
        var existing = await _repo.ExistingGroupIdsAsync(groupIds, ct);
        var missing = groupIds.Where(g => !existing.Contains(g)).ToList();
        if (missing.Count > 0)
            throw new BusinessRuleException("GROUP_NOT_FOUND", $"Không tìm thấy nhóm tuỳ chỉnh: {string.Join(", ", missing)}.");

        var baseProduct = await _repo.FindBaseProductForUpdateAsync(productId, ct);
        if (baseProduct is null)
        {
            baseProduct = new BaseProduct { Idsanpham = productId };
            _repo.Add(baseProduct);
        }
        baseProduct.IsCustomizable = request.IsCustomizable;

        foreach (var link in baseProduct.OptionGroupLinks.Where(l => !groupIds.Contains(l.OptionGroupId)).ToList())
            baseProduct.OptionGroupLinks.Remove(link);

        for (var i = 0; i < groupIds.Count; i++)
        {
            var link = baseProduct.OptionGroupLinks.FirstOrDefault(l => l.OptionGroupId == groupIds[i]);
            if (link is null)
                baseProduct.OptionGroupLinks.Add(new BaseProductOptionGroup { Idsanpham = productId, OptionGroupId = groupIds[i], SortOrder = i });
            else
                link.SortOrder = i;
        }

        await _repo.SaveChangesAsync(ct);
        return (await ListBaseProductsAsync(ct)).First(p => p.ProductId == productId);
    }

    // ---------------- Kiểm tra dữ liệu & ánh xạ ----------------

    /// <summary>
    /// Kiểm tra cấu hình nhóm: tên bắt buộc (400); MinSelect &gt;= 0, MaxSelect &gt;= 1 và MinSelect &lt;= MaxSelect (422).
    /// Nhóm bắt buộc mà MinSelect = 0 vẫn hợp lệ vì khi chọn sẽ tự hiểu là tối thiểu 1; nhưng MaxSelect phải &gt;= mức tối thiểu đó.
    /// </summary>
    private static string ValidateGroup(UpsertOptionGroupRequest r)
    {
        var name = r.Name?.Trim();
        if (string.IsNullOrEmpty(name) || name.Length > 100)
            throw new RequestValidationException("INVALID_GROUP_NAME", "Tên nhóm bắt buộc và tối đa 100 ký tự.");
        if (r.Description is { Length: > 255 })
            throw new RequestValidationException("INVALID_DESCRIPTION", "Mô tả tối đa 255 ký tự.");
        if (r.MinSelect < 0 || r.MaxSelect < 1)
            throw new RequestValidationException("INVALID_RANGE", "MinSelect phải >= 0 và MaxSelect phải >= 1.");

        var effectiveMin = r.IsRequired ? Math.Max(r.MinSelect, 1) : r.MinSelect;
        if (effectiveMin > r.MaxSelect)
            throw new BusinessRuleException("MIN_GREATER_THAN_MAX", "MinSelect không được lớn hơn MaxSelect.");
        return name;
    }

    private static string ValidateOption(UpsertOptionRequest r)
    {
        var name = r.Name?.Trim();
        if (string.IsNullOrEmpty(name) || name.Length > 100)
            throw new RequestValidationException("INVALID_OPTION_NAME", "Tên lựa chọn bắt buộc và tối đa 100 ký tự.");
        if (r.ExtraPrice < 0)
            throw new RequestValidationException("INVALID_PRICE", "Giá cộng thêm không được âm.");
        if (r.ExtraPrice != decimal.Truncate(r.ExtraPrice))
            throw new RequestValidationException("INVALID_PRICE", "Giá cộng thêm phải là số nguyên đồng.");
        if (r.MaxQuantity is < 1 or > 20)
            throw new RequestValidationException("INVALID_MAX_QUANTITY", "MaxQuantity phải từ 1 đến 20.");
        return name;
    }

    private static void Apply(OptionGroup g, UpsertOptionGroupRequest r, string name)
    {
        g.Name = name;
        g.Description = string.IsNullOrWhiteSpace(r.Description) ? null : r.Description.Trim();
        g.IsRequired = r.IsRequired;
        g.MinSelect = r.MinSelect;
        g.MaxSelect = r.MaxSelect;
        g.SortOrder = r.SortOrder;
        g.IsActive = r.IsActive;
    }

    private static void Apply(DrinkOption o, UpsertOptionRequest r, string name)
    {
        o.Name = name;
        o.ExtraPrice = r.ExtraPrice;
        o.MaxQuantity = r.MaxQuantity;
        o.IsDefault = r.IsDefault;
        o.IsActive = r.IsActive;
        o.SortOrder = r.SortOrder;
    }

    private static OptionDto ToDto(DrinkOption o) => new(
        o.Id, o.OptionGroupId, o.Name, o.ExtraPrice, o.MaxQuantity, o.IsDefault, o.IsActive, o.SortOrder,
        o.Ingredients.OrderBy(i => i.Idnguyenlieu)
            .Select(i => new OptionIngredientDto(i.Idnguyenlieu, i.Nguyenlieu?.Tennguyenlieu, i.Nguyenlieu?.Donvitinh, i.ConsumptionQuantity))
            .ToList());

    private static OptionGroupDto ToDto(OptionGroup g) => new(
        g.Id, g.Name, g.Description, g.IsRequired, g.MinSelect, g.MaxSelect, g.SortOrder, g.IsActive,
        g.Options.OrderBy(o => o.SortOrder).ThenBy(o => o.Id).Select(ToDto).ToList());

    private static NotFoundException GroupNotFound() => new("GROUP_NOT_FOUND", "Không tìm thấy nhóm tuỳ chỉnh.");
    private static NotFoundException OptionNotFound() => new("OPTION_NOT_FOUND", "Không tìm thấy lựa chọn.");
}
