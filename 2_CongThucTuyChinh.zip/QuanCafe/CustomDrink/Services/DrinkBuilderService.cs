using System.Security.Cryptography;
using System.Text;
using QuanCafe.CustomDrink.Dtos;
using QuanCafe.CustomDrink.Entities;
using QuanCafe.CustomDrink.Exceptions;
using QuanCafe.CustomDrink.Repositories;

namespace QuanCafe.CustomDrink.Services;

public interface IDrinkBuilderService
{
    /// <summary>Danh sách nhóm tuỳ chỉnh + lựa chọn mà khách được phép chọn cho một món nền.</summary>
    Task<BuilderMenuDto> GetBuilderMenuAsync(int baseProductId, CancellationToken ct);

    /// <summary>Kiểm tra cấu hình và tính giá + định lượng nguyên liệu. Ném lỗi 400/404/422 nếu không hợp lệ.</summary>
    Task<DrinkQuote> QuoteAsync(int baseProductId, IReadOnlyList<OptionSelectionDto>? selectedOptions, CancellationToken ct);
}

/// <summary>Trình tạo món: kiểm tra ràng buộc cấu hình và tính giá tự động.</summary>
public sealed class DrinkBuilderService : IDrinkBuilderService
{
    private const int MaxQuantityPerOption = 99;

    private readonly IOptionCatalogRepository _catalog;

    public DrinkBuilderService(IOptionCatalogRepository catalog) => _catalog = catalog;

    public async Task<BuilderMenuDto> GetBuilderMenuAsync(int baseProductId, CancellationToken ct)
    {
        var catalog = await LoadCatalogAsync(baseProductId, ct);
        var groups = catalog.Groups.Select(g => new BuilderGroupDto(
            g.Id, g.Name, g.Description, g.IsRequired, g.EffectiveMin, g.MaxSelect,
            g.Options.OrderBy(o => o.SortOrder).ThenBy(o => o.Id)
                .Select(o => new BuilderOptionDto(o.Id, o.Name, o.ExtraPrice, o.MaxQuantity, o.IsDefault))
                .ToList())).ToList();

        return new BuilderMenuDto(catalog.Product.Idsanpham, catalog.Product.Tensanpham, catalog.Product.Gia, catalog.Product.Hinhanh, groups);
    }

    public async Task<DrinkQuote> QuoteAsync(int baseProductId, IReadOnlyList<OptionSelectionDto>? selectedOptions, CancellationToken ct)
    {
        var selections = NormalizeSelections(selectedOptions);
        var catalog = await LoadCatalogAsync(baseProductId, ct);

        var errors = ValidateSelections(catalog.Groups, selections);
        if (errors.Count > 0)
            throw new BusinessRuleException("INVALID_CUSTOMIZATION", errors[0].Message, errors);

        return BuildQuote(catalog, selections);
    }

    private async Task<BuilderCatalog> LoadCatalogAsync(int baseProductId, CancellationToken ct)
    {
        var catalog = await _catalog.GetBuilderCatalogAsync(baseProductId, ct)
            ?? throw new NotFoundException("BASE_PRODUCT_NOT_FOUND", "Món nền không tồn tại hoặc đã tạm hết.");

        if (catalog.Base is null || !catalog.Base.IsCustomizable)
            throw new BusinessRuleException("BASE_NOT_CUSTOMIZABLE", "Món này không hỗ trợ tự tuỳ chỉnh.");

        return catalog;
    }

    /// <summary>
    /// Gộp các dòng trùng OptionId (cộng dồn số lượng) và loại bỏ dữ liệu sai định dạng.
    /// Số lượng &lt;= 0 hoặc OptionId &lt;= 0 là lỗi 400.
    /// </summary>
    public static Dictionary<int, int> NormalizeSelections(IReadOnlyList<OptionSelectionDto>? selected)
    {
        var result = new Dictionary<int, int>();
        if (selected is null) return result;

        foreach (var s in selected)
        {
            if (s is null || s.OptionId <= 0)
                throw new RequestValidationException("INVALID_OPTION_ID", "Mã tuỳ chọn không hợp lệ.");
            if (s.Quantity <= 0)
                throw new RequestValidationException("INVALID_QUANTITY", $"Số lượng của tuỳ chọn #{s.OptionId} phải lớn hơn 0.");

            var total = (result.TryGetValue(s.OptionId, out var old) ? old : 0) + s.Quantity;
            if (total > MaxQuantityPerOption)
                throw new RequestValidationException("INVALID_QUANTITY", $"Số lượng của tuỳ chọn #{s.OptionId} quá lớn.");
            result[s.OptionId] = total;
        }
        return result;
    }

    /// <summary>
    /// Kiểm tra cấu hình món theo các nhóm được gán cho món nền. Trả về TẤT CẢ lỗi tìm được (danh sách rỗng = hợp lệ):
    /// <list type="bullet">
    /// <item><description>OPTION_NOT_ALLOWED: lựa chọn không thuộc nhóm nào của món nền (hoặc đã bị tắt).</description></item>
    /// <item><description>GROUP_REQUIRED: nhóm <c>IsRequired</c> nhưng khách chưa chọn gì.</description></item>
    /// <item><description>GROUP_MIN / GROUP_MAX: tổng số lượng chọn trong nhóm nhỏ hơn <c>MinSelect</c> / lớn hơn <c>MaxSelect</c>.
    /// Nhóm bắt buộc luôn cần tối thiểu 1; nhóm không bắt buộc cho phép không chọn gì, nhưng đã chọn thì phải &gt;= MinSelect.</description></item>
    /// <item><description>OPTION_QUANTITY_EXCEEDED: số lượng một lựa chọn vượt <c>MaxQuantity</c> của nó (ví dụ tối đa 2 phần trân châu).</description></item>
    /// </list>
    /// Hàm thuần (không truy cập database) nên dễ viết unit test.
    /// </summary>
    /// <param name="groups">Các nhóm đang bật của món nền, kèm lựa chọn đang bật.</param>
    /// <param name="selections">OptionId -> số lượng (đã qua <see cref="NormalizeSelections"/>).</param>
    public static IReadOnlyList<ErrorItem> ValidateSelections(
        IReadOnlyCollection<OptionGroup> groups, IReadOnlyDictionary<int, int> selections)
    {
        var errors = new List<ErrorItem>();
        var knownOptionIds = groups.SelectMany(g => g.Options).Select(o => o.Id).ToHashSet();

        foreach (var optionId in selections.Keys.Where(id => !knownOptionIds.Contains(id)))
            errors.Add(new ErrorItem("OPTION_NOT_ALLOWED", $"selectedOptions[{optionId}]",
                $"Tuỳ chọn #{optionId} không hợp lệ với món nền này."));

        foreach (var group in groups)
        {
            var chosen = group.Options.Where(o => selections.ContainsKey(o.Id)).ToList();
            var total = chosen.Sum(o => selections[o.Id]);
            var field = $"groups[{group.Id}]";

            foreach (var option in chosen.Where(o => selections[o.Id] > o.MaxQuantity))
                errors.Add(new ErrorItem("OPTION_QUANTITY_EXCEEDED", field,
                    $"Số lượng {option.Name} vượt quá giới hạn (tối đa {option.MaxQuantity})."));

            if (total == 0)
            {
                if (group.IsRequired)
                    errors.Add(new ErrorItem("GROUP_REQUIRED", field, $"{group.Name} là bắt buộc."));
                continue;
            }

            var min = group.EffectiveMin;
            if (total < min)
                errors.Add(new ErrorItem("GROUP_MIN", field, $"Cần chọn ít nhất {min} lựa chọn cho {group.Name}."));
            if (total > group.MaxSelect)
                errors.Add(new ErrorItem("GROUP_MAX", field,
                    $"Số lượng {group.Name} vượt quá giới hạn (tối đa {group.MaxSelect})."));
        }

        return errors;
    }

    /// <summary>
    /// Tính giá và định lượng cho MỘT ly (cấu hình đã được kiểm tra hợp lệ):
    /// <c>Giá món custom = Giá món nền + ∑(Số lượng × Giá extra của lựa chọn)</c>.
    /// Nguyên liệu tiêu hao = công thức gốc của món nền (congthucsanpham) + ∑(Số lượng × định lượng của lựa chọn),
    /// gộp theo nguyên liệu. Giá luôn lấy từ database, không tin dữ liệu client.
    /// </summary>
    public static DrinkQuote BuildQuote(BuilderCatalog catalog, IReadOnlyDictionary<int, int> selections)
    {
        var lines = new List<QuoteOptionLine>();
        var stock = new Dictionary<int, (string Name, string Unit, decimal Qty)>();

        void AddStock(int id, string name, string unit, decimal qty)
        {
            stock[id] = stock.TryGetValue(id, out var cur) ? (cur.Name, cur.Unit, cur.Qty + qty) : (name, unit, qty);
        }

        foreach (var group in catalog.Groups)
        {
            foreach (var option in group.Options.OrderBy(o => o.SortOrder).ThenBy(o => o.Id))
            {
                if (!selections.TryGetValue(option.Id, out var qty)) continue;

                lines.Add(new QuoteOptionLine(option.Id, group.Name, option.Name, qty, option.ExtraPrice, option.ExtraPrice * qty));
                foreach (var ing in option.Ingredients)
                    AddStock(ing.Idnguyenlieu, ing.Nguyenlieu.Tennguyenlieu, ing.Nguyenlieu.Donvitinh, ing.ConsumptionQuantity * qty);
            }
        }

        foreach (var c in catalog.BaseRecipe)
            AddStock(c.Idnguyenlieu, c.IdnguyenlieuNavigation.Tennguyenlieu, c.IdnguyenlieuNavigation.Donvitinh, c.Soluongcanthiet);

        var extraTotal = lines.Sum(l => l.LineTotal);
        var ingredients = stock
            .OrderBy(kv => kv.Key)
            .Select(kv => new IngredientConsumption(kv.Key, kv.Value.Name, kv.Value.Unit, kv.Value.Qty))
            .ToList();

        return new DrinkQuote(
            catalog.Product.Idsanpham,
            catalog.Product.Tensanpham,
            catalog.Product.Gia,
            extraTotal,
            catalog.Product.Gia + extraTotal,
            lines,
            ingredients,
            Describe(lines),
            ComputeConfigHash(catalog.Product.Idsanpham, selections));
    }

    /// <summary>Mô tả ngắn, ví dụ "Size: L; Mức đường: 50%; Topping: Trân châu x2, Cream cheese".</summary>
    public static string Describe(IEnumerable<QuoteOptionLine> lines) =>
        string.Join("; ", lines.GroupBy(l => l.GroupName).Select(g =>
            $"{g.Key}: " + string.Join(", ", g.Select(l => l.Quantity > 1 ? $"{l.OptionName} x{l.Quantity}" : l.OptionName))));

    /// <summary>
    /// Mã băm SHA-256 (64 ký tự hex) của "món nền + các lựa chọn sắp xếp theo Id". Hai cấu hình giống hệt nhau
    /// luôn cho cùng mã bất kể thứ tự khách chọn, dùng để gộp thống kê vào cùng một CustomRecipe.
    /// </summary>
    public static string ComputeConfigHash(int baseProductId, IReadOnlyDictionary<int, int> selections)
    {
        var canonical = $"{baseProductId}|" + string.Join(",", selections.OrderBy(k => k.Key).Select(k => $"{k.Key}x{k.Value}"));
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonical))).ToLowerInvariant();
    }
}
