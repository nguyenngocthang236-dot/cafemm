using Microsoft.Extensions.Options;
using QuanCafe.CustomDrink.Dtos;
using QuanCafe.CustomDrink.Entities;
using QuanCafe.CustomDrink.Exceptions;
using QuanCafe.CustomDrink.Infrastructure;
using QuanCafe.CustomDrink.Repositories;

namespace QuanCafe.CustomDrink.Services;

/// <summary>Chuyển entity công thức sang DTO (cần đã Include Sanpham, Details, Option, OptionGroup).</summary>
public static class RecipeMapper
{
    /// <summary>Giá hiện tại của công thức = giá món nền hiện tại + ∑(số lượng × giá extra hiện tại).</summary>
    public static decimal CurrentPrice(CustomRecipe r) =>
        r.Sanpham.Gia + r.Details.Sum(d => d.Option.ExtraPrice * d.Quantity);

    public static IReadOnlyList<RecipeOptionDto> ToOptions(CustomRecipe r) =>
        r.Details
            .OrderBy(d => d.Option.OptionGroup.SortOrder).ThenBy(d => d.Option.OptionGroup.Id)
            .ThenBy(d => d.Option.SortOrder).ThenBy(d => d.OptionId)
            .Select(d => new RecipeOptionDto(d.OptionId, d.Option.OptionGroup.Name, d.Option.Name, d.Quantity))
            .ToList();

    /// <summary>Còn bán được không: món nền còn hàng và mọi lựa chọn / nhóm vẫn đang bật.</summary>
    public static bool IsAvailable(CustomRecipe r) =>
        r.Sanpham.Conhang == true && r.Details.All(d => d.Option.IsActive && d.Option.OptionGroup.IsActive);

    public static IReadOnlyList<OptionSelectionDto> ToSelections(CustomRecipe r) =>
        r.Details.Select(d => new OptionSelectionDto(d.OptionId, d.Quantity)).ToList();

    public static SavedRecipeDto ToDto(UserSavedRecipe s) => new(
        s.Id, s.Name, s.Note, s.IsPublic, s.OrderCount, s.CustomRecipeId,
        s.CustomRecipe.Idsanpham, s.CustomRecipe.Sanpham.Tensanpham, ToOptions(s.CustomRecipe),
        CurrentPrice(s.CustomRecipe), IsAvailable(s.CustomRecipe), s.CreatedAt, s.UpdatedAt);
}

// ============================================================================================
// Công thức đã lưu (khách hàng)
// ============================================================================================
public interface ISavedRecipeService
{
    Task<SavedRecipeDto> SaveAsync(Guid customerId, SaveRecipeRequest request, CancellationToken ct);
    Task<PagedResult<SavedRecipeDto>> ListAsync(Guid customerId, string? search, int page, int pageSize, CancellationToken ct);
    Task<SavedRecipeDto> GetAsync(Guid customerId, int id, CancellationToken ct);
    Task<SavedRecipeDto> UpdateAsync(Guid customerId, int id, UpdateRecipeRequest request, CancellationToken ct);
    Task DeleteAsync(Guid customerId, int id, CancellationToken ct);
}

public sealed class SavedRecipeService : ISavedRecipeService
{
    public const int MaxNameLength = 100;
    public const int MaxNoteLength = 500;

    private readonly IDrinkBuilderService _builder;
    private readonly ICustomRecipeRepository _recipes;
    private readonly ISavedRecipeRepository _saved;
    private readonly CustomDrinkOptions _options;

    public SavedRecipeService(
        IDrinkBuilderService builder, ICustomRecipeRepository recipes, ISavedRecipeRepository saved,
        IOptions<CustomDrinkOptions> options)
    {
        _builder = builder;
        _recipes = recipes;
        _saved = saved;
        _options = options.Value;
    }

    public async Task<SavedRecipeDto> SaveAsync(Guid customerId, SaveRecipeRequest request, CancellationToken ct)
    {
        var name = NormalizeName(request.Name);
        var note = NormalizeNote(request.Note);

        // Kiểm tra lại toàn bộ ràng buộc: không bao giờ lưu cấu hình sai dù client gửi gì.
        var quote = await _builder.QuoteAsync(request.BaseProductId, request.SelectedOptions, ct);

        if (await _saved.CountAsync(customerId, ct) >= _options.MaxSavedRecipesPerCustomer)
            throw new BusinessRuleException("SAVED_LIMIT_REACHED",
                $"Bạn chỉ có thể lưu tối đa {_options.MaxSavedRecipesPerCustomer} công thức. Hãy xoá bớt công thức cũ.");
        if (await _saved.NameExistsAsync(customerId, name, null, ct))
            throw new ConflictException("RECIPE_NAME_DUPLICATE", $"Bạn đã có công thức tên \"{name}\".");

        var recipe = await _recipes.GetOrCreateAsync(quote, ct);
        if (await _saved.ExistsForRecipeAsync(customerId, recipe.Id, ct))
            throw new ConflictException("RECIPE_ALREADY_SAVED", "Bạn đã lưu cấu hình món này rồi.");

        var saved = new UserSavedRecipe
        {
            CustomerId = customerId,
            CustomRecipeId = recipe.Id,
            Name = name,
            Note = note,
            IsPublic = request.IsPublic,
            CreatedAt = DateTime.Now,
            UpdatedAt = DateTime.Now
        };
        _saved.Add(saved);
        await _saved.SaveChangesAsync(ct); // trùng do đua request -> DbUpdateException -> 409 qua exception filter

        return await GetAsync(customerId, saved.Id, ct);
    }

    public async Task<PagedResult<SavedRecipeDto>> ListAsync(
        Guid customerId, string? search, int page, int pageSize, CancellationToken ct)
    {
        page = Math.Max(page, 1);
        pageSize = Math.Clamp(pageSize, 1, 50);

        var (items, total) = await _saved.SearchAsync(customerId, search, page, pageSize, ct);
        return new PagedResult<SavedRecipeDto>(items.Select(RecipeMapper.ToDto).ToList(), page, pageSize, total);
    }

    public async Task<SavedRecipeDto> GetAsync(Guid customerId, int id, CancellationToken ct)
    {
        var saved = await _saved.GetAsync(customerId, id, tracking: false, ct)
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");
        return RecipeMapper.ToDto(saved);
    }

    public async Task<SavedRecipeDto> UpdateAsync(Guid customerId, int id, UpdateRecipeRequest request, CancellationToken ct)
    {
        var saved = await _saved.GetAsync(customerId, id, tracking: true, ct)
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");

        if (request.Name is not null)
        {
            var name = NormalizeName(request.Name);
            if (await _saved.NameExistsAsync(customerId, name, id, ct))
                throw new ConflictException("RECIPE_NAME_DUPLICATE", $"Bạn đã có công thức tên \"{name}\".");
            saved.Name = name;
        }
        if (request.Note is not null) saved.Note = NormalizeNote(request.Note);
        if (request.IsPublic.HasValue) saved.IsPublic = request.IsPublic.Value;

        saved.UpdatedAt = DateTime.Now;
        await _saved.SaveChangesAsync(ct);
        return RecipeMapper.ToDto(saved);
    }

    public async Task DeleteAsync(Guid customerId, int id, CancellationToken ct)
    {
        var saved = await _saved.GetAsync(customerId, id, tracking: true, ct)
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");
        _saved.Remove(saved); // chỉ xoá bản lưu; CustomRecipe (cấu hình) và số lượt đặt vẫn giữ cho thống kê
        await _saved.SaveChangesAsync(ct);
    }

    private static string NormalizeName(string? name)
    {
        name = name?.Trim();
        if (string.IsNullOrEmpty(name))
            throw new RequestValidationException("NAME_REQUIRED", "Tên công thức không được để trống.");
        if (name.Length > MaxNameLength)
            throw new RequestValidationException("NAME_TOO_LONG", $"Tên công thức tối đa {MaxNameLength} ký tự.");
        return name;
    }

    private static string? NormalizeNote(string? note)
    {
        note = string.IsNullOrWhiteSpace(note) ? null : note.Trim();
        if (note is { Length: > MaxNoteLength })
            throw new RequestValidationException("NOTE_TOO_LONG", $"Ghi chú tối đa {MaxNoteLength} ký tự.");
        return note;
    }
}

// ============================================================================================
// Thống kê cộng đồng
// ============================================================================================
public interface ICommunityRecipeService
{
    Task<IReadOnlyList<CommunityRecipeDto>> GetTopAsync(int take, int? baseProductId, CancellationToken ct);
}

public sealed class CommunityRecipeService : ICommunityRecipeService
{
    private readonly ICustomRecipeRepository _recipes;

    public CommunityRecipeService(ICustomRecipeRepository recipes) => _recipes = recipes;

    /// <summary>Top công thức do khách tự phối được đặt nhiều nhất; chỉ gồm công thức có ít nhất một người chọn công khai.</summary>
    public async Task<IReadOnlyList<CommunityRecipeDto>> GetTopAsync(int take, int? baseProductId, CancellationToken ct)
    {
        take = Math.Clamp(take, 1, 50);
        var rows = await _recipes.GetTopCommunityAsync(take, baseProductId, ct);

        return rows.Select(r => new CommunityRecipeDto(
            r.Recipe.Id, r.DisplayName, r.Recipe.Idsanpham, r.Recipe.Sanpham.Tensanpham,
            RecipeMapper.ToOptions(r.Recipe), RecipeMapper.CurrentPrice(r.Recipe),
            r.Recipe.OrderCount, r.SavedByCount)).ToList();
    }
}
