using Microsoft.Extensions.Options;
using QuanCafe.CustomDrink.Dtos;
using QuanCafe.CustomDrink.Exceptions;
using QuanCafe.CustomDrink.Infrastructure;
using QuanCafe.CustomDrink.Repositories;

namespace QuanCafe.CustomDrink.Services;

public interface ICustomOrderService
{
    Task<CartDto> GetCartAsync(CancellationToken ct);
    Task<CartDto> AddToCartAsync(AddToCartRequest request, CancellationToken ct);
    Task<CartDto> AddSavedRecipeToCartAsync(Guid customerId, int savedRecipeId, int quantity, CancellationToken ct);
    Task<CartDto> RemoveFromCartAsync(int customRecipeId, CancellationToken ct);
    Task<CheckoutResultDto> CheckoutAsync(CheckoutRequest request, Guid? customerId, CancellationToken ct);
}

/// <summary>
/// Giỏ hàng + đặt hàng cho món tự chọn. Giỏ nằm trong Session với khoá riêng ("GioHangTuyChinh") nên
/// không đụng giỏ hàng cũ; đơn tạo ra vẫn là Donhang/Chitietdon bình thường nên nhân viên và dashboard thấy như mọi đơn khác.
/// </summary>
public sealed class CustomOrderService : ICustomOrderService
{
    /// <summary>Khớp với giới hạn mỗi món tối đa 20 ly của GioHangController.</summary>
    public const int MaxQuantityPerLine = 20;
    public const int MaxLines = 20;

    private readonly IDrinkBuilderService _builder;
    private readonly ICustomRecipeRepository _recipes;
    private readonly ISavedRecipeRepository _saved;
    private readonly ICustomOrderRepository _orders;
    private readonly ICustomDrinkSession _session;
    private readonly CustomDrinkOptions _options;

    public CustomOrderService(
        IDrinkBuilderService builder, ICustomRecipeRepository recipes, ISavedRecipeRepository saved,
        ICustomOrderRepository orders, ICustomDrinkSession session, IOptions<CustomDrinkOptions> options)
    {
        _builder = builder;
        _recipes = recipes;
        _saved = saved;
        _orders = orders;
        _session = session;
        _options = options.Value;
    }

    public async Task<CartDto> GetCartAsync(CancellationToken ct)
    {
        var lines = new List<CartLineDto>();
        foreach (var item in _session.LoadCart())
        {
            try
            {
                // Tính lại giá từ database mỗi lần xem giỏ: giá/tuỳ chọn đổi hoặc bị tắt thì khách thấy ngay.
                var quote = await QuoteItemAsync(item, ct);
                lines.Add(new CartLineDto(item.CustomRecipeId, item.SavedRecipeId, item.Quantity, quote, quote.UnitPrice * item.Quantity, null));
            }
            catch (CustomDrinkException ex)
            {
                lines.Add(new CartLineDto(item.CustomRecipeId, item.SavedRecipeId, item.Quantity, null, 0m, ex.Message));
            }
        }

        return new CartDto(lines, lines.Where(l => l.Problem is null).Sum(l => l.Quantity), lines.Sum(l => l.LineTotal));
    }

    public async Task<CartDto> AddToCartAsync(AddToCartRequest request, CancellationToken ct)
    {
        ValidateQuantity(request.Quantity);
        var quote = await _builder.QuoteAsync(request.BaseProductId, request.SelectedOptions, ct);
        var recipe = await _recipes.GetOrCreateAsync(quote, ct);

        AddItem(recipe.Id, null, request.Quantity);
        return await GetCartAsync(ct);
    }

    /// <summary>Re-order: đưa công thức đã lưu vào giỏ, kiểm tra lại ràng buộc phòng khi quán đã đổi cấu hình tuỳ chọn.</summary>
    public async Task<CartDto> AddSavedRecipeToCartAsync(Guid customerId, int savedRecipeId, int quantity, CancellationToken ct)
    {
        ValidateQuantity(quantity);
        var saved = await _saved.GetAsync(customerId, savedRecipeId, tracking: false, ct)
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Không tìm thấy công thức đã lưu.");

        await _builder.QuoteAsync(saved.CustomRecipe.Idsanpham, RecipeMapper.ToSelections(saved.CustomRecipe), ct);

        AddItem(saved.CustomRecipeId, saved.Id, quantity);
        return await GetCartAsync(ct);
    }

    public Task<CartDto> RemoveFromCartAsync(int customRecipeId, CancellationToken ct)
    {
        var cart = _session.LoadCart();
        cart.RemoveAll(x => x.CustomRecipeId == customRecipeId);
        _session.SaveCart(cart);
        return GetCartAsync(ct);
    }

    public async Task<CheckoutResultDto> CheckoutAsync(CheckoutRequest request, Guid? customerId, CancellationToken ct)
    {
        var idPhien = _session.IdPhien;
        var idBan = _session.IdBan;
        if (idPhien is null || idBan is null || !await _orders.IsTableSessionOpenAsync(idPhien.Value, idBan.Value, ct))
            throw new UnauthorizedTableException();

        var cart = _session.LoadCart();
        if (cart.Count == 0)
            throw new BusinessRuleException("CART_EMPTY", "Giỏ hàng món tự chọn đang trống.");

        // Tính lại và kiểm tra lại TOÀN BỘ giỏ ngay lúc đặt: cấu hình lỗi thời thì dừng với lỗi 422 cụ thể.
        var lines = new List<PlaceOrderLine>();
        foreach (var item in cart)
        {
            var quote = await QuoteItemAsync(item, ct);
            lines.Add(new PlaceOrderLine(
                item.CustomRecipeId, item.SavedRecipeId, quote.BaseProductId, item.Quantity,
                quote.UnitPrice, quote.Description, quote.Ingredients));
        }

        var note = string.IsNullOrWhiteSpace(request.Note) ? null : request.Note.Trim();
        if (note is { Length: > 200 }) note = note[..200]; // giống giới hạn của GioHangController.DatHang

        var placed = await _orders.PlaceAsync(idPhien.Value, idBan.Value, note, customerId, lines, _options.EnforceStock, ct);

        _session.ClearCart(); // chỉ xoá giỏ sau khi transaction đã commit
        return new CheckoutResultDto(placed.OrderId, placed.OrderCode, placed.Total, placed.StockDeducted);
    }

    // ---------- Hàm phụ ----------

    private async Task<DrinkQuote> QuoteItemAsync(CustomCartItem item, CancellationToken ct)
    {
        var recipe = await _recipes.GetWithDetailsAsync(item.CustomRecipeId, ct)
            ?? throw new NotFoundException("RECIPE_NOT_FOUND", "Công thức trong giỏ không còn tồn tại.");
        return await _builder.QuoteAsync(recipe.Idsanpham, RecipeMapper.ToSelections(recipe), ct);
    }

    private void AddItem(int customRecipeId, int? savedRecipeId, int quantity)
    {
        var cart = _session.LoadCart();
        var line = cart.FirstOrDefault(x => x.CustomRecipeId == customRecipeId && x.SavedRecipeId == savedRecipeId);
        if (line is null)
        {
            if (cart.Count >= MaxLines)
                throw new BusinessRuleException("CART_FULL", $"Giỏ hàng món tự chọn tối đa {MaxLines} dòng.");
            cart.Add(new CustomCartItem { CustomRecipeId = customRecipeId, SavedRecipeId = savedRecipeId, Quantity = quantity });
        }
        else
        {
            line.Quantity = Math.Min(line.Quantity + quantity, MaxQuantityPerLine);
        }
        _session.SaveCart(cart);
    }

    private static void ValidateQuantity(int quantity)
    {
        if (quantity < 1 || quantity > MaxQuantityPerLine)
            throw new RequestValidationException("INVALID_QUANTITY", $"Số lượng phải từ 1 đến {MaxQuantityPerLine}.");
    }
}
