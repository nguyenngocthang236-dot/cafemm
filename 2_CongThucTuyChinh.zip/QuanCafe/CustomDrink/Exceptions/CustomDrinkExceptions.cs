using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;

namespace QuanCafe.CustomDrink.Exceptions;

/// <summary>Một lỗi chi tiết trả về cho client: mã lỗi, trường liên quan và thông báo tiếng Việt.</summary>
public sealed record ErrorItem(string Code, string? Field, string Message);

/// <summary>Lớp cha của các lỗi nghiệp vụ; <see cref="CustomDrinkExceptionFilter"/> đổi chúng thành HTTP status chuẩn.</summary>
public abstract class CustomDrinkException : Exception
{
    protected CustomDrinkException(int statusCode, string code, string message, IReadOnlyList<ErrorItem>? errors = null)
        : base(message)
    {
        StatusCode = statusCode;
        Code = code;
        Errors = errors ?? new[] { new ErrorItem(code, null, message) };
    }

    public int StatusCode { get; }
    public string Code { get; }
    public IReadOnlyList<ErrorItem> Errors { get; }
}

/// <summary>400 - dữ liệu gửi lên sai định dạng (số lượng &lt;= 0, tên rỗng...).</summary>
public sealed class RequestValidationException : CustomDrinkException
{
    public RequestValidationException(string code, string message, IReadOnlyList<ErrorItem>? errors = null)
        : base(StatusCodes.Status400BadRequest, code, message, errors) { }
}

/// <summary>404 - không tìm thấy món nền / công thức / tuỳ chọn.</summary>
public sealed class NotFoundException : CustomDrinkException
{
    public NotFoundException(string code, string message)
        : base(StatusCodes.Status404NotFound, code, message) { }
}

/// <summary>401 - khách chưa quét QR tại bàn hoặc phiên bàn đã đóng (giống màn hình "ChuaQuetQr" của code gốc).</summary>
public sealed class UnauthorizedTableException : CustomDrinkException
{
    public UnauthorizedTableException()
        : base(StatusCodes.Status401Unauthorized, "TABLE_SESSION_REQUIRED", "Hãy quét mã QR tại bàn trước khi đặt món.") { }
}

/// <summary>409 - trùng tên, trùng công thức đã lưu, dữ liệu vừa bị người khác sửa.</summary>
public sealed class ConflictException : CustomDrinkException
{
    public ConflictException(string code, string message)
        : base(StatusCodes.Status409Conflict, code, message) { }
}

/// <summary>422 - dữ liệu đúng định dạng nhưng vi phạm ràng buộc nghiệp vụ (thiếu mức đường, quá số topping...).</summary>
public sealed class BusinessRuleException : CustomDrinkException
{
    public BusinessRuleException(string code, string message, IReadOnlyList<ErrorItem>? errors = null)
        : base(StatusCodes.Status422UnprocessableEntity, code, message, errors) { }
}

/// <summary>
/// Bộ lọc lỗi chỉ áp dụng cho các controller của tính năng này (qua <c>CustomDrinkApiController</c>),
/// nên không đụng tới <c>UseExceptionHandler</c> hay các controller cũ.
/// </summary>
public sealed class CustomDrinkExceptionFilter : IExceptionFilter
{
    private readonly ILogger<CustomDrinkExceptionFilter> _logger;

    public CustomDrinkExceptionFilter(ILogger<CustomDrinkExceptionFilter> logger) => _logger = logger;

    public void OnException(ExceptionContext context)
    {
        switch (context.Exception)
        {
            case CustomDrinkException ex:
                context.Result = Build(ex.StatusCode, ex.Code, ex.Message, ex.Errors);
                context.ExceptionHandled = true;
                break;

            case DbUpdateException ex: // gồm cả DbUpdateConcurrencyException
                _logger.LogWarning(ex, "Lỗi lưu dữ liệu tính năng món tự chọn.");
                context.Result = Build(StatusCodes.Status409Conflict, "DATA_CONFLICT",
                    "Dữ liệu vừa bị thay đổi hoặc bị trùng. Vui lòng tải lại rồi thử lại.", null);
                context.ExceptionHandled = true;
                break;
        }
    }

    private static ObjectResult Build(int status, string code, string message, IReadOnlyList<ErrorItem>? errors)
    {
        var problem = new ProblemDetails
        {
            Status = status,
            Title = message,
            Type = $"https://httpstatuses.com/{status}"
        };
        problem.Extensions["code"] = code;
        problem.Extensions["errors"] = errors ?? new[] { new ErrorItem(code, null, message) };

        var result = new ObjectResult(problem) { StatusCode = status };
        result.ContentTypes.Add("application/problem+json");
        return result;
    }
}
