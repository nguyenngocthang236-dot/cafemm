# 1. Chức năng Kho hàng

Quản lý tồn kho theo từng món (`sanpham.soluongton`): nhập thêm / giảm bớt, báo "sắp hết", "hết hàng"; khách không đặt được quá số còn lại.

## Các file trong gói
| File | Vai trò |
|---|---|
| `Controllers/KhoController.cs` | API `POST /api/sanpham/{id}/ton-kho` (+n nhập, -n giảm) |
| `Helpers/KhoHang.cs` | Hàm cộng/trừ tồn nguyên tử trong SQL Server, hằng `SapHet`, `ToiDa` |
| `Models/Nguyenlieu.cs`, `Lichsukho.cs`, `Congthucsanpham.cs` | Bảng nguyên liệu, lịch sử kho, công thức (nguyên liệu của món) |
| `Migrations/AddTonKho.sql` | Thêm cột `soluongton` cho `sanpham` (chạy 1 lần trên SQL Server) |
| `Views/QuanLy/_KhoModal.cshtml` | Giao diện modal "Kiểm tra kho hàng" |
| `wwwroot/js/kho.js`, `wwwroot/css/kho.css` | Script và style của modal kho |

## Gắn vào dự án (các file dùng chung, không nằm trong gói)
1. `Views/QuanLy/Dashboard.cshtml`:
   - trong `<head>`: `<link rel="stylesheet" href="~/css/kho.css" asp-append-version="true" />`
   - thay khối modal kho bằng `<partial name="_KhoModal" />`
   - sau dòng nạp `dashboard.js`: `<script src="~/js/kho.js" asp-append-version="true"></script>` (phải nạp SAU dashboard.js)
   - giữ nút mở modal có `id="nut-kiem-tra-kho"` trong dashboard.
2. `wwwroot/js/dashboard.js` phải xuất cầu nối `window.DashboardCore = { goiApi, taiDanhSachMon, hienToast, anhHienThiCuaMon, thoatHtml, layDanhSachMon }` (kho.js dùng lại các hàm này).
3. `Models/Sanpham.cs` có thuộc tính `Soluongton` (int) và `Models/AppDbContext.cs` có các `DbSet` cho Nguyenlieu, Lichsukho, Congthucsanpham.
4. Nơi khác đang gọi `KhoHang.ThayDoiAsync`: `GioHangController.DatHang` (trừ kho khi đặt), `QuanLyController.HuyDon` (hoàn kho khi hủy đơn), và CustomDrink (trừ kho món tự tạo).

## Chạy
Chạy `Migrations/AddTonKho.sql` trên database `QuanCafe`, build, mở Dashboard -> "Kiểm tra kho hàng".
