/* =========================================================
   kho.js - modal "Kiểm tra kho hàng" của trang /Menu/Dashboard.
   Tách riêng khỏi dashboard.js. Phải nạp SAU dashboard.js vì dùng window.DashboardCore.
   API: POST /api/sanpham/{id}/ton-kho  (KhoController)
   ========================================================= */
(function () {
  'use strict';

  var core = window.DashboardCore;
  if (!core) { console.error('kho.js cần nạp sau dashboard.js'); return; }
  var goiApi = core.goiApi;
  var taiDanhSachMon = core.taiDanhSachMon;
  var hienToast = core.hienToast;
  var anhHienThiCuaMon = core.anhHienThiCuaMon;
  var thoatHtml = core.thoatHtml;
  function dsMon() { return core.layDanhSachMon(); }

  // ========================================================
  // MODAL: Kiểm tra kho hàng (tồn kho theo từng món)
  //   - Danh sách lấy thẳng từ bảng sanpham => thêm món mới là món đó có mặt ở đây.
  //   - Nhập thêm / giảm bớt gửi lên server dạng "thay đổi +n / -n" (server cộng trừ nguyên tử),
  //     nên không bị ghi đè khi khách đang đặt hàng cùng lúc.
  // ========================================================

  var SAP_HET = 5; // còn từng này trở xuống thì báo "sắp hết" (khớp KhoHang.SapHet ở server)
  var KHOANG_LAM_MOI_KHO = 15000;

  var modalKho = document.getElementById('modal-kho');
  var khoDs = document.getElementById('kho-ds');
  var khoTongQuan = document.getElementById('kho-tong-quan');
  var khoRong = document.getElementById('kho-rong');

  var luongDangGo = {};     // id món -> số đang nhập ở ô điều chỉnh (giữ lại khi danh sách được vẽ lại)
  var khoIdsDangVe = '';    // danh sách id đang hiển thị, để biết khi nào phải vẽ lại cả danh sách
  var khoTimer = null;

  function tonCuaMon(mon) { return Number(mon.tonKho) || 0; }

  function trangThaiKho(ton) {
    if (ton <= 0) return { lop: 'het', chu: 'Hết hàng' };
    if (ton <= SAP_HET) return { lop: 'sap', chu: 'Sắp hết' };
    return { lop: 'con', chu: 'Còn hàng' };
  }

  function soCoDauCham(so) {
    return String(so).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  function theTongQuan(nhan, so, lop) {
    return '<div class="kho-the' + (lop ? ' kho-the--' + lop : '') + '">' +
      '<span class="kho-the__so">' + soCoDauCham(so) + '</span>' +
      '<span class="kho-the__nhan">' + thoatHtml(nhan) + '</span></div>';
  }

  function renderTongQuanKho() {
    var tongLuong = 0, het = 0, sap = 0;
    dsMon().forEach(function (mon) {
      var ton = tonCuaMon(mon);
      tongLuong += ton;
      if (ton <= 0) het += 1; else if (ton <= SAP_HET) sap += 1;
    });
    khoTongQuan.innerHTML =
      theTongQuan('Số món trong kho', dsMon().length) +
      theTongQuan('Tổng số lượng tồn', tongLuong) +
      theTongQuan('Món sắp hết', sap, sap > 0 ? 'sap' : '') +
      theTongQuan('Món hết hàng', het, het > 0 ? 'het' : '');
  }

  function htmlDongKho(mon) {
    var ton = tonCuaMon(mon);
    var tt = trangThaiKho(ton);
    var luong = luongDangGo[mon.id] != null ? luongDangGo[mon.id] : '1';
    return '<div class="kho-dong' + (ton <= 0 ? ' kho-dong--het' : '') + '" data-id="' + mon.id + '">' +
      '<img class="kho-dong__anh" src="' + thoatHtml(anhHienThiCuaMon(mon)) + '" alt="' + thoatHtml(mon.ten) + '" />' +
      '<div class="kho-dong__ten"><strong>' + thoatHtml(mon.ten) + '</strong>' +
        '<span>' + thoatHtml(mon.loai || 'Chưa phân loại') + '</span></div>' +
      '<div class="kho-dong__ton">' +
        '<span class="kho-so">' + soCoDauCham(ton) + '</span>' +
        '<span class="kho-tag kho-tag--' + tt.lop + '">' + tt.chu + '</span></div>' +
      '<div class="kho-dong__dieu-chinh">' +
        '<button type="button" class="kho-nut kho-nut--giam" data-hanh-dong="giam" aria-label="Giảm tồn kho của ' + thoatHtml(mon.ten) + '">−</button>' +
        '<input type="number" class="kho-nhap" min="1" max="99999" step="1" value="' + thoatHtml(luong) + '" aria-label="Số lượng điều chỉnh của ' + thoatHtml(mon.ten) + '" />' +
        '<button type="button" class="kho-nut kho-nut--tang" data-hanh-dong="tang" aria-label="Nhập thêm tồn kho của ' + thoatHtml(mon.ten) + '">+</button>' +
      '</div></div>';
  }

  // Vẽ lại toàn bộ danh sách (khi mở modal, hoặc khi có món được thêm / xóa)
  function renderKho() {
    renderTongQuanKho();
    khoIdsDangVe = dsMon().map(function (m) { return m.id; }).join(',');
    khoRong.hidden = dsMon().length > 0;
    khoDs.innerHTML = dsMon().map(htmlDongKho).join('');
  }

  // Chỉ cập nhật số liệu từng dòng, giữ nguyên ô nhập đang gõ dở
  function capNhatDongKho(mon) {
    var dong = khoDs.querySelector('.kho-dong[data-id="' + mon.id + '"]');
    if (!dong) return;
    var ton = tonCuaMon(mon);
    var tt = trangThaiKho(ton);
    dong.classList.toggle('kho-dong--het', ton <= 0);
    dong.querySelector('.kho-so').textContent = soCoDauCham(ton);
    var tag = dong.querySelector('.kho-tag');
    tag.className = 'kho-tag kho-tag--' + tt.lop;
    tag.textContent = tt.chu;
  }

  // Tải lại từ server (để thấy cả những đơn khách vừa đặt làm kho giảm)
  function lamMoiKho() {
    return taiDanhSachMon().then(function () {
      if (modalKho.hidden) return;
      var ids = dsMon().map(function (m) { return m.id; }).join(',');
      if (ids !== khoIdsDangVe) {
        renderKho();
      } else {
        dsMon().forEach(capNhatDongKho);
        renderTongQuanKho();
      }
    });
  }

  function moModalKho() {
    modalKho.hidden = false;
    luongDangGo = {};
    khoDs.innerHTML = '';
    khoIdsDangVe = '';
    taiDanhSachMon().then(renderKho).catch(function () {
      hienToast('Không tải được dữ liệu kho.', true);
    });
    clearInterval(khoTimer);
    khoTimer = setInterval(function () { lamMoiKho().catch(function () {}); }, KHOANG_LAM_MOI_KHO);
  }

  function dongModalKho() {
    modalKho.hidden = true;
    clearInterval(khoTimer);
    khoTimer = null;
  }

  document.getElementById('nut-kiem-tra-kho').addEventListener('click', moModalKho);
  document.getElementById('nut-dong-modal-kho').addEventListener('click', dongModalKho);
  modalKho.addEventListener('click', function (e) { if (e.target === modalKho) dongModalKho(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !modalKho.hidden) dongModalKho();
  });

  // Nhớ số đang gõ ở từng ô điều chỉnh
  khoDs.addEventListener('input', function (e) {
    var o = e.target.closest('.kho-nhap');
    if (!o) return;
    var dong = o.closest('.kho-dong');
    if (dong) luongDangGo[dong.dataset.id] = o.value;
  });

  // Bấm + / − : gửi "thay đổi" lên server
  khoDs.addEventListener('click', function (e) {
    var nut = e.target.closest('.kho-nut');
    if (!nut || nut.disabled) return;
    var dong = nut.closest('.kho-dong');
    var mon = dsMon().find(function (m) { return m.id === Number(dong.dataset.id); });
    if (!mon) return;

    var o = dong.querySelector('.kho-nhap');
    var soLuong = Number(o.value);
    if (!isFinite(soLuong) || soLuong < 1 || Math.floor(soLuong) !== soLuong) {
      hienToast('Nhập số lượng nguyên lớn hơn 0.', true);
      o.focus();
      return;
    }

    var giam = nut.dataset.hanhDong === 'giam';
    var tonCu = tonCuaMon(mon);
    if (giam && soLuong > tonCu) {
      hienToast('Trong kho chỉ còn ' + tonCu + ', không thể giảm ' + soLuong + '.', true);
      return;
    }

    var cacNut = dong.querySelectorAll('.kho-nut');
    cacNut.forEach(function (n) { n.disabled = true; });

    goiApi('POST', '/api/sanpham/' + mon.id + '/ton-kho', { thayDoi: giam ? -soLuong : soLuong })
      .then(function (kq) {
        mon.tonKho = kq.tonKho;
        mon.conHang = kq.conHang;
        capNhatDongKho(mon);
        renderTongQuanKho();
        hienToast((giam ? 'Đã giảm ' : 'Đã nhập thêm ') + soLuong + ' · ' + mon.ten + ' còn ' + kq.tonKho + '.');
      })
      .catch(function (err) {
        hienToast(err.message || 'Không cập nhật được tồn kho.', true);
        lamMoiKho().catch(function () {});   // số liệu có thể đã đổi: tải lại cho đúng
      })
      .finally(function () {
        cacNut.forEach(function (n) { n.disabled = false; });
      });
  });
})();
