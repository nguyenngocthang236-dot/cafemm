using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuanCafe.Helpers;
using QuanCafe.Models;

namespace QuanCafe.Controllers;

/// <summary>API quản lý tồn kho của từng món (tách riêng khỏi QuanLyController).</summary>
public class KhoController : Controller
{
    private readonly AppDbContext _db;
    private readonly ILogger<KhoController> _logger;

    public KhoController(AppDbContext db, ILogger<KhoController> logger)
    {
        _db = db;
        _logger = logger;
    }

    // POST /api/sanpham/{id}/ton-kho   body: { "thayDoi": 5 }  hoặc  { "thayDoi": -3 }
    // Số dương = nhập thêm vào kho, số âm = giảm bớt. Việc cộng/trừ làm ngay trong SQL Server
    // nên không bị lệch khi khách đang đặt hàng cùng lúc.
    [HttpPost("api/sanpham/{id:int}/ton-kho")]
    public async Task<IActionResult> DieuChinhTonKho(int id, [FromBody] TonKhoRequest? req)
    {
        if (req == null || req.ThayDoi == 0)
            return BadRequest(new { loi = "Số lượng thay đổi phải khác 0." });
        if (Math.Abs((long)req.ThayDoi) > KhoHang.ToiDa)
            return BadRequest(new { loi = $"Mỗi lần chỉ được thay đổi tối đa {KhoHang.ToiDa}." });

        if (!await _db.Sanphams.AnyAsync(s => s.Idsanpham == id))
            return NotFound(new { loi = "Không tìm thấy món." });

        try
        {
            if (!await KhoHang.ThayDoiAsync(_db, id, req.ThayDoi))
            {
                // Số liệu vừa đổi (khách đặt hàng) hoặc vượt giới hạn: đọc lại để báo cho đúng.
                var hienTai = await DocTonKhoAsync(id);
                var loiKho = req.ThayDoi < 0
                    ? $"Trong kho chỉ còn {hienTai}, không thể giảm {-req.ThayDoi}."
                    : $"Tồn kho tối đa là {KhoHang.ToiDa} (hiện có {hienTai}).";
                return Conflict(new { loi = loiKho, tonKho = hienTai });
            }
        }
        catch (Microsoft.Data.SqlClient.SqlException ex)
        {
            _logger.LogError(ex, "Không cập nhật được tồn kho món {IdSanPham}", id);
            return StatusCode(500, new { loi = "Không cập nhật được tồn kho. Bạn đã chạy file Migrations/AddTonKho.sql trên SQL Server chưa?" });
        }

        var moi = await DocTonKhoAsync(id);
        return Ok(new { ok = true, id, tonKho = moi, conHang = moi > 0 });
    }

    private Task<int> DocTonKhoAsync(int id) =>
        _db.Sanphams.AsNoTracking()
            .Where(s => s.Idsanpham == id)
            .Select(s => s.Soluongton)
            .FirstOrDefaultAsync();
}

public sealed record TonKhoRequest(int ThayDoi);
