# 3. Giao diện nhân viên

Màn hình nhân viên xử lý đơn: xem đơn đang chờ, chuyển từng món `cholam -> danglam -> xong`, khi tất cả món xong thì đơn "sẵn sàng giao", rồi xác nhận giao cho khách.

## Các file trong gói
| File | Vai trò |
|---|---|
| `Controllers/NhanVienController.cs` | `GET /NhanVien/DanhSachDon`, `POST CapNhatMon`, `POST XacNhanGiao` |
| `Views/NhanVien/DanhSachDon.cshtml` | Giao diện danh sách đơn của nhân viên (có hiện mô tả món tự tạo) |
| `Helpers/DonHangStatus.cs` | Hằng trạng thái đơn khớp CHECK constraint của DB: `choxacnhan, danglam, sansanggiao, dagiao, huy` |
| `Models/Nhanvien.cs` | Entity nhân viên |

## Phụ thuộc (không nằm trong gói)
- `Models/AppDbContext.cs`, `Donhang.cs`, `Chitietdon.cs`, `Ban.cs`, `Sanpham.cs`.
- `Views/Shared/_Layout.cshtml` làm layout mặc định.
- `DonHangStatus` cũng được dùng ở `GioHangController`, `ThanhToanController`, `QuanLyController`.

## Chạy
Mở `/NhanVien/DanhSachDon`. Không cần SQL riêng; dùng các bảng có sẵn.
